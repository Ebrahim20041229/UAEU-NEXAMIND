# Security and privacy — implemented controls

This describes the submitted prototype, not a certification or guarantee of security.

| Protection | Implemented evidence |
|---|---|
| Local processing | CSV and image selection use browser File APIs; there is no application upload endpoint or AI/analytics request. |
| Minimized retention | Product values, evidence, review decisions and drafts stay in page memory. Persistent localStorage contains language preference only. Legacy v2/v3 inventory caches are cleared on startup and session deletion. |
| User deletion | Clear session data removes uploaded records, image references, draft state and in-memory patches; blob URLs are revoked. Pending file reads cannot repopulate a cleared session. |
| Safe image types | File signatures and extensions must match JPEG/PNG/WebP. SVG and disguised files are rejected. 10 MB per image, 50 images and 100 MB combined maximum. This is type/size validation, not antivirus or full image-decoder validation. |
| CSV limits | 2 MB; at most 1000 records, 64 columns and 10000 characters per cell. Required headers, quoting, row widths, duplicate/unsafe IDs and invalid values are checked. |
| Untrusted text | React renders user/CSV content as text; no raw-HTML rendering or runtime evaluation is used. Exports are user-triggered plain-text drafts. |
| Network restrictions | OPEN_SITE.html has a hash-based Content Security Policy: only its packaged script/styles execute; outbound fetch, external image URLs, frames, plugins and form submissions are blocked. The policy is generated from the final packaged bytes. |
| Development exposure | Vite binds to 127.0.0.1 with explicit local hostnames. Preview sets nosniff, no-referrer and framing restrictions. These are not a production access-control system. |
| Packaging | No node_modules, environment secrets, production credentials, browser logs or identifiable customer data are required/included. Demonstration records are synthetic. |

## What deletion does not mean
Clearing the session removes application-owned references; it is not a secure wipe of browser/OS memory. It does not delete the user's original files, downloaded exports, clipboard, screenshots, browser history or backups. The user owns those files. Reload/closing the page loses the current inventory. Export only what the seller intends to share.

## Threat model and remaining work
This offline, single-user prototype reduces accidental retention and network disclosure. It does not provide login, roles, multi-tenant isolation, audit-server retention, encryption at rest or protection against compromised browsers/devices/extensions. Image signatures do not detect all malicious payloads. No penetration test, legal compliance certification or independent security audit was performed. HTTPS, authentication/authorization, server-side revalidation, tenant isolation, retention policy, secret management and security review are required before a real hosted pilot.

## Reproduction checks
Verify normal demo files work; reject SVG renamed to .jpg and oversized inputs; reject duplicate/unsafe IDs; inspect application storage for absence of inventory; press Clear session data and verify no product/image remains. Use browser developer tools to inspect CSP and confirm no application data leaves the page. Browser enforcement/visual tests remain for the receiving team; automated checks performed are listed in TEST_RESULTS.md.
