# Submission verification — 2026-10-28

Passed on the submitted security revision:
- TypeScript project checks and Vite production build.
- React DOM/JSDOM interaction tests: normal import, explicit Save, P009 year conflict resolution and AED 810 ready value, original evidence retained, P005 identifier confirmation, P010 position resolution, invalid-year blocking, review/reject status persistence, manual-draft preservation, Arabic document direction/labels and image URL lifetime.
- Privacy action clears inventory/image UI and leaves no persistent inventory entry.
- All ten original demonstration images accepted; renamed SVG and oversized image rejected.
- Oversized CSV/cell and duplicate/unsafe product IDs rejected.
- Standalone CSP script/style hashes verified against exact packaged bytes.
- Self-contained HTML startup/language toggle was tested in JSDOM; JSDOM does not enforce CSP. Full visual browser testing, browser-policy enforcement and independent penetration testing were not completed.

No encryption, authentication, security certification, model accuracy or measured manual-workflow speed improvement is claimed. See SECURITY.md and SUBMISSION_NOTE.md.

## Reproducible internal regression suite

33 automated Node tests passed on the internal reliability revision (see reports/validation-results.json for actual command output, runtime and date). Cases cover source-cell provenance, normal/conflict correction, confirmation invalidation, rejected functionality, mixed-currency priority, decimal totals, lot pricing, strict CSV quoting/limits, image signatures, memory-only storage and source isolation. Two tests lock the 28 interface files and the App JSX against the prior submission. Compiled CSS was also compared byte-for-byte and remained identical.

React DOM/JSDOM interaction tests were rerun for import, review decisions, editing, year correction, Arabic direction and session clearing. No browser pixel-comparison, independent penetration test, measured manual time savings or model-accuracy benchmark is claimed.

## Compact evidence display

The latest suite has 38 passing tests. Five additional checks cover concise default content, exact CSV source pointers for seller edits, both conflicting year values, preserved raw English evidence, Arabic enum labels and missing-source behavior. The explicit user-requested changes are EvidenceFieldCard.tsx and Arabic translation entries; the other 26 original UI/style files and App JSX remain unchanged. Full records remain accessible under Source details and history.
