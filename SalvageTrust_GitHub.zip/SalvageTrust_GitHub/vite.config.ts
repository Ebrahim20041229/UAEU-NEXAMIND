import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
 plugins:[react()],
 server:{host:"127.0.0.1",allowedHosts:["localhost","127.0.0.1"],headers:{"X-Content-Type-Options":"nosniff","Referrer-Policy":"no-referrer"}},
 preview:{host:"127.0.0.1",allowedHosts:["localhost","127.0.0.1"],headers:{"X-Content-Type-Options":"nosniff","Referrer-Policy":"no-referrer","X-Frame-Options":"DENY","Content-Security-Policy":"default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' blob: data:; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"}}
});
