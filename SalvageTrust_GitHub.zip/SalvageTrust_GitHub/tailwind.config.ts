import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter", "Noto Sans", "ui-sans-serif", "system-ui", "sans-serif"]
      },
      colors: {
        trust: {
          bg: "#F7F9FC",
          panel: "#FFFFFF",
          card: "#FFFFFF",
          blue: "#2563EB",
          cyan: "#0891B2",
          teal: "#0F766E",
          green: "#166534",
          amber: "#92400E",
          red: "#991B1B",
          muted: "#475569"
        }
      },
      boxShadow: {
        card: "0 12px 34px rgba(15, 23, 42, 0.08)",
        soft: "0 8px 24px rgba(15, 118, 110, 0.12)"
      }
    }
  },
  plugins: [require("tailwindcss-animate")]
};

export default config;
