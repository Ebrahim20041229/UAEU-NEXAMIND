@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js was not found. Open OPEN_SITE.html instead.
 pause
 exit /b 1
)
if not exist node_modules (
 call npm ci --legacy-peer-deps
 if errorlevel 1 (
  pause
  exit /b 1
 )
)
call npm run dev:source -- --port 5173
pause
