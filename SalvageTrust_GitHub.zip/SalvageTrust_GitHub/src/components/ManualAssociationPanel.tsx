import { useT } from "../i18n/locale";
import type { ProductWorkspaceRecord, UploadedImage } from "../types/salvage";

interface Props {
  images: UploadedImage[];
  products: ProductWorkspaceRecord[];
  onAssociate: (imageId: string, productId: string) => void;
}

export function ManualAssociationPanel({ images, products, onAssociate }: Props) {
  const t = useT();
  const unmatched = images.filter((image) => !products.some((product) => product.imageIds.includes(image.id)));
  if (!unmatched.length || !products.length) return null;

  return (
    <section className="rounded-2xl border border-amber-200 bg-amber-50 p-4">
      <h3 className="font-semibold text-amber-900">{t("Manual image association")}</h3>
      <p className="mt-1 text-sm text-amber-800">{t("These images were not matched by explicit CSV filenames. Choose a product only after checking the file.")}</p>
      <div className="mt-3 grid gap-3 md:grid-cols-2">
        {unmatched.map((image) => (
          <article key={image.id} className="flex items-center gap-3 rounded-xl border border-amber-200 bg-white p-3">
            <img src={image.previewUrl} alt={image.name} className="h-12 w-12 rounded-md object-contain" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-[#172B4D]">{image.name}</p>
              <select
                value=""
                onChange={(event) => event.target.value && onAssociate(image.id, event.target.value)}
                className="mt-2 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-[#172B4D] focus:outline-none focus:ring-2 focus:ring-teal-600"
                aria-label={t(`Associate ${image.name} to product`)}
              >
                <option value="">{t("Associate to product...")}</option>
                {products.map((product) => <option key={product.id} value={product.id}>{product.displayName}</option>)}
              </select>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
