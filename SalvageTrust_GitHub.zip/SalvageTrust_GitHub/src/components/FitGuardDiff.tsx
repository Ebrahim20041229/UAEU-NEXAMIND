import { Ban, CheckCircle2, ShieldAlert } from "lucide-react";
import type { ListingDraft, PartRecord } from "../types/salvage";

interface Props {
  part: PartRecord;
  draft: ListingDraft;
}

export function FitGuardDiff({ part, draft }: Props) {
  const removed = draft.claims.find((claim) => claim.status === "removed");
  const compatibility = draft.claims.find((claim) => claim.claimType === "compatibility");

  return (
    <section className="relative overflow-hidden rounded-3xl border border-cyan-300/20 bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 p-5 shadow-glow">
      <div className="absolute -right-12 -top-12 h-44 w-44 rounded-full bg-cyan-400/20 blur-3xl" />
      <div className="relative flex items-center gap-3">
        <div className="rounded-2xl bg-cyan-300/10 p-3 text-cyan-200">
          <ShieldAlert size={24} />
        </div>
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.24em] text-cyan-300">FitGuard Diff</p>
          <h2 className="text-xl font-bold text-white">The wow moment: AI claim blocked before publication</h2>
        </div>
      </div>

      <div className="relative mt-5 grid gap-4 lg:grid-cols-3">
        <div className="rounded-2xl border border-red-400/30 bg-red-500/10 p-4">
          <div className="mb-2 flex items-center gap-2 text-red-100"><Ban size={18} /> Unsafe attempted claim</div>
          <p className="text-sm text-slate-200">{part.attemptedUnsafeClaim ?? "Broad compatibility claim attempted by generic AI."}</p>
        </div>
        <div className="rounded-2xl border border-amber-400/30 bg-amber-400/10 p-4">
          <div className="mb-2 flex items-center gap-2 text-amber-100"><ShieldAlert size={18} /> FitGuard reason</div>
          <p className="text-sm text-slate-200">{removed?.reason ?? "Claim is allowed only if it exists in the approved compatibility reference dataset."}</p>
        </div>
        <div className="rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-4">
          <div className="mb-2 flex items-center gap-2 text-emerald-100"><CheckCircle2 size={18} /> Safe final output</div>
          <p className="text-sm text-slate-200">{compatibility?.status === "supported" ? compatibility.text : "Donor vehicle shown only. Broader compatibility remains unverified until evidence is supplied."}</p>
        </div>
      </div>
    </section>
  );
}
