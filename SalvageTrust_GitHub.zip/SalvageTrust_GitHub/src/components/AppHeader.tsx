import { useT } from "../i18n/locale";
import { Upload } from "lucide-react";
import type { Language } from "../types/salvage";
import { copy } from "../i18n/copy";

interface Props {
  language: Language;
  onToggleLanguage: () => void;
  onAddFiles: () => void;
  onRestart: () => void;
}

export function AppHeader({ language, onToggleLanguage, onAddFiles, onRestart }: Props) {
  const t = useT();
  const labels = copy[language];
  return (
    <header className="fixed inset-x-0 top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex min-h-16 max-w-7xl flex-wrap items-center justify-between gap-2 py-3 px-4 sm:px-6">
        <div>
          <p className="text-base font-bold text-[#172B4D]">{t("SalvageTrust AI")}</p>
          <p className="text-xs text-slate-500">{t("eBay listing evidence workspace")}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button type="button" onClick={onRestart} className="rounded-lg border px-3 py-2 text-xs">{t("Restart demo")}</button>
          <button
            type="button"
            onClick={onToggleLanguage}
            className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-teal-600"
          >
            {labels.language}
          </button>
          <button
            type="button"
            onClick={onAddFiles}
            className="inline-flex items-center gap-2 rounded-lg bg-[#0F766E] px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[#115E59] focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2"
          >
            <Upload size={16} />
            {labels.addFiles}
          </button>
        </div>
      </div>
    </header>
  );
}
