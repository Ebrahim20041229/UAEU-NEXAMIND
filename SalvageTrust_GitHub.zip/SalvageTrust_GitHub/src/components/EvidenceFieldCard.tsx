import { useT } from "../i18n/locale";
import { AlertTriangle, CheckCircle2, Eye, Pencil, XCircle } from "lucide-react";
import { useEffect, useState } from "react";
import type { EvidenceField, EvidenceSource, ProductFieldKey } from "../types/salvage";
import { StatusBadge } from "./StatusBadge";
import { buildEvidencePreview, briefEvidenceIssue, evidenceDisplayValue, pointerFor } from "../lib/evidencePreview";

interface Props {
  field: EvidenceField;
  onChange: (key: ProductFieldKey, value: string) => void;
  onConfirm: (key: ProductFieldKey) => void;
  onNeedsReview: (key: ProductFieldKey) => void;
  onReject: (key: ProductFieldKey) => void;
}

const borderFor = (status: EvidenceField["status"]) => {
  if (["supported", "seller_confirmed"].includes(status)) return "border-emerald-200 bg-emerald-50/40";
  if (["missing", "invalid", "conflict", "rejected"].includes(status)) return "border-red-200 bg-red-50/50";
  return "border-amber-200 bg-amber-50/40";
};


function SourceCard({ source }: { source: EvidenceSource }) {
  const t = useT();
  return (
    <div className="rounded-md bg-slate-50 p-2">
      <p className="font-semibold text-slate-800">{t(source.label)}</p>
      <p dir="auto" className="text-slate-600">{t(source.location ?? source.fileName ?? "Source location not available")}</p>
      <p dir="auto" className="mt-1 text-slate-700">“{source.snippet}”</p>
      {source.createdAt && <p>{source.createdAt}</p>}
      {source.reason && <p>{t(source.reason)}</p>}
      {source.originalSource && (
        <p className="mt-1 text-xs text-slate-500">{t("Original:")}{source.originalSource.file} · {source.originalSource.column} ({source.originalSource.cell}) · “{source.originalSource.value}”</p>
      )}
    </div>
  );
}

export function EvidenceDetails({field}:{field:EvidenceField}) {
  const t = useT();
  const [showDetails,setShowDetails] = useState(false);
  const preview = buildEvidencePreview(field);
  const displayValue = preview.value.length > 120 ? t("Open details to read the full text.") : evidenceDisplayValue(field,t);
  return <div className="mt-3 rounded-lg border border-slate-200 bg-white p-3 text-sm text-slate-700">
    <dl className="space-y-2">
      <div className="flex flex-wrap items-baseline gap-x-2 gap-y-1">
        <dt className="font-semibold text-slate-500">{t("Source")}</dt>
        <dd className="min-w-0" title={preview.pointer.file}>
          {t(preview.label)}
          {preview.pointer.row !== undefined && <> · {t("Row")} {preview.pointer.row}</>}
          {preview.pointer.cell && <> · <bdi dir="ltr">{preview.pointer.cell}</bdi></>}
        </dd>
      </div>
      <div className="flex flex-wrap items-baseline gap-x-2 gap-y-1">
        <dt className="font-semibold text-slate-500">{t("Value")}</dt>
        <dd className="min-w-0 break-words"><bdi dir="auto">{displayValue}</bdi></dd>
      </div>
      {preview.alternatives.map(source => <div key={source.id} className="flex flex-wrap items-baseline gap-x-2 gap-y-1">
        <dt className="font-semibold text-slate-500">{t("Other source")}</dt>
        <dd><bdi dir="ltr">{pointerFor(source).cell}</bdi> · <bdi dir="auto">{source.value ?? source.snippet}</bdi></dd>
      </div>)}
    </dl>
    <details className="mt-3 border-t border-slate-100 pt-2" onToggle={event => setShowDetails(event.currentTarget.open)}>
      <summary className="cursor-pointer text-xs font-semibold text-teal-700">{t("Source details and history")}</summary>
      {showDetails && <div className="mt-3 space-y-2">
        {field.issue && <p className="text-xs text-slate-600">{t(field.issue)}</p>}
        {preview.details.map(source => <SourceCard key={source.id} source={source} />)}
      </div>}
    </details>
  </div>;
}

export function EvidenceFieldCard({ field, onChange, onConfirm, onNeedsReview, onReject }: Props) {
  const t = useT();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [inputValue, setInputValue] = useState(field.value ?? "");
  useEffect(() => { setInputValue(field.value ?? ""); }, [field.value, field.key]);
  const choices: Partial<Record<ProductFieldKey,string[]>> = {position:["left","right","center","rear","left_right","set","unconfirmed"], condition:["used","for_parts"], testingStatus:["tested_working","untested","not_recorded","faulty"],partNumberLegibility:["clear","unclear","missing"]};
  const startEditing = () => { setInputValue(field.value ?? ""); setEditing(true); };
  const confirm = () => {
    if (field.value && (["supported","seller_confirmed","rejected"].includes(field.status) || field.code === "identifier_needs_confirmation" || field.code === "seller_review")) onConfirm(field.key);
    else startEditing();
  };
  const briefIssue = briefEvidenceIssue(field);

  return (
    <article className={`rounded-xl border p-4 ${borderFor(field.status)}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <label className="text-sm font-semibold text-[#172B4D]" htmlFor={`field-${field.key}`}>{t(field.label)}</label>
          {editing ? (
            <div className="mt-2 space-y-2">
            {choices[field.key] ? <select id={`field-${field.key}`} value={inputValue} onChange={event => setInputValue(event.target.value)} className="w-full rounded-lg border bg-white px-3 py-2">
              <option value="">{t("Choose value")}</option>
              {choices[field.key]!.map(value => <option key={value} value={value}>{t(value)}</option>)}
              {inputValue && !choices[field.key]!.includes(inputValue) && <option value={inputValue}>{inputValue}</option>}
            </select> : <input id={`field-${field.key}`} value={inputValue} dir="auto" onChange={event => setInputValue(event.target.value)} autoFocus
              onKeyDown={event => { if (event.key === "Escape") setEditing(false); if (event.key === "Enter") { onChange(field.key,inputValue.trim()); setEditing(false); } }}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-600" />}
            <div className="flex flex-wrap gap-2">
              <button type="button" onClick={() => { onChange(field.key,inputValue.trim()); setEditing(false); }} className="rounded-lg bg-teal-700 px-3 py-2 text-white">{t("Save changes")}</button>
              <button type="button" onClick={() => setEditing(false)} className="rounded-lg border px-3 py-2">{t("Cancel")}</button>
            </div>
            </div>
          ) : (
            <button type="button" onClick={startEditing} disabled={field.key === "productId"} className="mt-2 block min-h-6 w-full truncate text-start text-sm text-slate-700 hover:text-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-600">
              {evidenceDisplayValue(field,t)}
            </button>
          )}
        </div>
        <StatusBadge status={field.status} />
      </div>

      {briefIssue && <p className="mt-3 flex gap-2 text-sm text-slate-700"><AlertTriangle className="mt-0.5 shrink-0 text-amber-700" size={15} />{t(briefIssue)}</p>}

      <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-slate-600">
        
        <button type="button" onClick={() => setOpen((value) => !value)} className="inline-flex items-center gap-1 rounded-md px-2 py-1 font-semibold text-teal-700 hover:bg-white focus:outline-none focus:ring-2 focus:ring-teal-600">
          <Eye size={14} /> {t(open ? "Hide evidence" : "View evidence")}
        </button>
      </div>

      {open && <EvidenceDetails field={field} />}

      <div className="mt-3 flex flex-wrap gap-2">
        <button type="button" onClick={startEditing} disabled={field.key === "productId"} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-teal-600"><Pencil size={13} />{t("Edit")}</button>
        <button type="button" onClick={confirm} className="inline-flex items-center gap-1 rounded-lg border border-emerald-200 bg-white px-3 py-1.5 text-xs font-semibold text-emerald-800 hover:bg-emerald-50 disabled:cursor-not-allowed disabled:opacity-50 focus:outline-none focus:ring-2 focus:ring-emerald-600"><CheckCircle2 size={13} />{t("Confirm")}</button>
        <button type="button" onClick={() => onNeedsReview(field.key)} className="rounded-lg border border-amber-200 bg-white px-3 py-1.5 text-xs font-semibold text-amber-800 hover:bg-amber-50 focus:outline-none focus:ring-2 focus:ring-amber-600">{t("Needs review")}</button>
        <button type="button" onClick={() => onReject(field.key)} className="inline-flex items-center gap-1 rounded-lg border border-red-200 bg-white px-3 py-1.5 text-xs font-semibold text-red-800 hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-red-600"><XCircle size={13} />{t("Reject")}</button>
      </div>
    </article>
  );
}
