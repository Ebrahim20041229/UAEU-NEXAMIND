import { useT } from "../i18n/locale";
import { AlertTriangle, FileSpreadsheet, ImagePlus, Trash2, UploadCloud } from "lucide-react";
import type { ProductWorkspaceRecord, UploadedCsvFile, UploadedImage } from "../types/salvage";

interface Props {
  images: UploadedImage[];
  csvFiles: UploadedCsvFile[];
  products: ProductWorkspaceRecord[];
  csvError?: string;
  onImagesSelected: (files: FileList | File[] | null) => void;
  onCsvSelected: (file: File | null) => void;
  onRemoveImage: (imageId: string) => void;
  onRemoveCsv: (fileId: string) => void;
}

export function UploadWorkspace({ images, csvFiles, products, csvError, onImagesSelected, onCsvSelected, onRemoveImage, onRemoveCsv }: Props) {
  const t = useT();
  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    const files = Array.from(event.dataTransfer.files);
    const imageFiles = files.filter((file) => file.type.startsWith("image/") || /\.(jpe?g|png|webp)$/i.test(file.name));
    const csvFile = files.find((file) => file.name.toLowerCase().endsWith(".csv"));
    if (imageFiles.length) onImagesSelected(imageFiles);
    if (csvFile) onCsvSelected(csvFile);
  };

  const imageStatus = (image: UploadedImage) => {
    const product = products.find((item) => item.imageIds.includes(image.id));
    if (product) return `matched to ${product.id}`;
    return image.matchStatus ?? "unmatched";
  };

  return (
    <section id="upload" className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h2 className="text-lg font-bold text-[#172B4D]">{t("Upload product files")}</h2>
          <p className="mt-1 max-w-2xl text-sm text-slate-600">{t("Upload the CSV inventory and photos. Matching uses exact product_id and image_filename values; image content is not analyzed automatically.")}</p>
        </div>
      </div>

      <div
        onDragOver={(event) => event.preventDefault()}
        onDrop={handleDrop}
        className="mt-4 rounded-xl border-2 border-dashed border-slate-300 bg-[#F7F9FC] p-5 text-center transition hover:border-teal-600 hover:bg-teal-50/40"
      >
        <UploadCloud className="mx-auto text-teal-700" size={28} />
        <p className="mt-2 font-semibold text-[#172B4D]">{t("Drop CSV and photos here")}</p>
        <p className="text-sm text-slate-500">{t("Required CSV columns include product_id and image_filename. Photos may be uploaded before or after the CSV.")}</p>
        <div className="mt-4 flex flex-wrap justify-center gap-3">
          <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg bg-[#0F766E] px-4 py-2 text-sm font-semibold text-white hover:bg-[#115E59] focus-within:ring-2 focus-within:ring-teal-600 focus-within:ring-offset-2">
            <ImagePlus size={16} />{t("Add images")}<input type="file" className="sr-only" accept="image/jpeg,image/png,image/webp" multiple onChange={(event) => onImagesSelected(event.target.files)} />
          </label>
          <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 focus-within:ring-2 focus-within:ring-teal-600 focus-within:ring-offset-2">
            <FileSpreadsheet size={16} />{t("Add CSV")}<input type="file" className="sr-only" accept=".csv,text/csv" onChange={(event) => onCsvSelected(event.target.files?.[0] ?? null)} />
          </label>
        </div>
      </div>

      {csvError && (
        <p className="mt-3 flex gap-2 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-800">
          <AlertTriangle className="mt-0.5 shrink-0" size={16} /> {t(csvError)}
        </p>
      )}

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <div>
          <p className="text-sm font-semibold text-slate-700">{t("Images")}</p>
          <div className="mt-2 grid gap-2 sm:grid-cols-2">
            {images.length === 0 && <p className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-500">{t("No images uploaded yet.")}</p>}
            {images.map((image) => (
              <article key={image.id} className="flex items-center gap-3 rounded-lg border border-slate-200 bg-white p-2">
                <img src={image.previewUrl} alt={image.name} className="h-14 w-14 rounded-md object-contain" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-[#172B4D]" title={image.name}>{image.name}</p>
                  <p className="text-xs text-slate-500">{Math.ceil(image.size / 1024)}{t("KB ·")}{t(imageStatus(image))}</p>
                </div>
                <button type="button" onClick={() => onRemoveImage(image.id)} className="rounded-md p-2 text-slate-500 hover:bg-red-50 hover:text-red-700 focus:outline-none focus:ring-2 focus:ring-red-600" aria-label={t(`Remove ${image.name}`)}>
                  <Trash2 size={16} />
                </button>
              </article>
            ))}
          </div>
        </div>

        <div>
          <p className="text-sm font-semibold text-slate-700">{t("CSV files")}</p>
          <div className="mt-2 space-y-2">
            {csvFiles.length === 0 && <p className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-500">{t("No CSV uploaded yet. Image-only records will show missing details until the inventory CSV is added.")}</p>}
            {csvFiles.map((file) => (
              <article key={file.id} className="flex items-start gap-3 rounded-lg border border-slate-200 bg-white p-3">
                <FileSpreadsheet className="mt-0.5 text-teal-700" size={18} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-[#172B4D]">{file.fileName}</p>
                  <p className="text-xs text-slate-500">{file.parsed.rows.length}{t("product row(s) ·")}{file.parsed.headers.length}{t("column(s)")}</p>
                  {Boolean(file.parsed.warnings?.length) && <p className="mt-1 text-xs text-amber-700">{file.parsed.warnings?.[0]}</p>}
                </div>
                <button type="button" onClick={() => onRemoveCsv(file.id)} className="rounded-md p-2 text-slate-500 hover:bg-red-50 hover:text-red-700 focus:outline-none focus:ring-2 focus:ring-red-600" aria-label={t(`Remove ${file.fileName}`)}>
                  <Trash2 size={16} />
                </button>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
