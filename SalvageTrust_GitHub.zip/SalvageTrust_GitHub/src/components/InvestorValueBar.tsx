import { BriefcaseBusiness, ShieldCheck, TrendingDown } from "lucide-react";

export function InvestorValueBar() {
  return (
    <nav className="fixed left-0 right-0 top-0 z-50 border-b border-white/10 bg-slate-950/90 backdrop-blur-2xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-cyan-300/15 text-cyan-200">
            <ShieldCheck size={22} />
          </div>
          <div>
            <p className="text-lg font-extrabold tracking-tight text-white">SalvageTrust AI</p>
            <p className="text-xs text-slate-400">Operational B2B listing validation</p>
          </div>
        </div>

        <div className="hidden items-center gap-2 lg:flex">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs font-semibold text-slate-200">
            <BriefcaseBusiness size={14} /> Built for salvage sellers
          </span>
          <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs font-semibold text-slate-200">
            <TrendingDown size={14} /> Reduces unsupported fitment returns
          </span>
        </div>
      </div>
    </nav>
  );
}
