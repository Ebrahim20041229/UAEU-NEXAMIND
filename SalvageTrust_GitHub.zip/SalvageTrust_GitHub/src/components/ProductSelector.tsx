import { useT } from "../i18n/locale";
import { ChevronDown, PackageSearch } from "lucide-react";
import { useState } from "react";
import type { ProductWorkspaceRecord, UploadedImage } from "../types/salvage";
import { StatusBadge } from "./StatusBadge";

interface Props {
  products: ProductWorkspaceRecord[];
  images: UploadedImage[];
  selectedId?: string;
  onSelect: (productId: string) => void;
}

export function ProductSelector({ products, images, selectedId, onSelect }: Props) {
  const t = useT();
  const [open, setOpen] = useState(false);
  const selected = products.find((product) => product.id === selectedId);
  const thumbFor = (product: ProductWorkspaceRecord) => images.find((image) => product.imageIds.includes(image.id));

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-bold text-[#172B4D]">{t("Select product")}</h2>
          <p className="text-sm text-slate-600">{t("Choose one product to analyze. Records stay isolated by product ID.")}</p>
        </div>
        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          disabled={!products.length}
          className="inline-flex items-center justify-between gap-3 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-[#172B4D] hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-60 focus:outline-none focus:ring-2 focus:ring-teal-600"
        >
          <span>{selected?.displayName ?? "Select product"}</span>
          <ChevronDown size={16} />
        </button>
      </div>

      {!products.length && (
        <div className="mt-4 rounded-xl border border-dashed border-slate-300 bg-slate-50 p-5 text-center text-sm text-slate-500">
          <PackageSearch className="mx-auto mb-2" size={24} />{t("Upload files to create product records.")}</div>
      )}

      {open && Boolean(products.length) && (
        <div className="mt-4 max-h-96 overflow-auto rounded-xl border border-slate-200 bg-white p-2 shadow-sm" role="listbox">
          {products.map((product) => {
            const thumb = thumbFor(product);
            const active = product.id === selectedId;
            return (
              <button
                type="button"
                key={product.id}
                onClick={() => { onSelect(product.id); setOpen(false); }}
                className={`flex w-full items-center gap-3 rounded-lg p-3 text-start transition hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-teal-600 ${active ? "bg-teal-50 ring-1 ring-teal-600" : ""}`}
                role="option"
                aria-selected={active}
              >
                {thumb ? <img src={thumb.previewUrl} alt="" className="h-12 w-12 rounded-md object-contain" /> : <div className="flex h-12 w-12 items-center justify-center rounded-md bg-slate-100 text-slate-500"><PackageSearch size={18} /></div>}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-[#172B4D]">{product.displayName}</p>
                  <p className="truncate text-xs text-slate-500">{t("ID:")}{" "}{product.id} · {product.associatedFilenames.join(", ") || "No matched image"}</p>
                  {product.matchIssue && <p className="mt-1 text-xs text-amber-700">{t(product.matchIssue)}</p>}
                </div>
                <StatusBadge status={product.readinessStatus} />
              </button>
            );
          })}
        </div>
      )}
    </section>
  );
}
