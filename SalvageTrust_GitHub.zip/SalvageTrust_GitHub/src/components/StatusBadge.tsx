import { useT } from "../i18n/locale";
import type { EvidenceStatus, ReadinessStatus } from "../types/salvage";

const evidenceStyles: Record<EvidenceStatus, string> = {
  supported: "border-emerald-200 bg-emerald-50 text-emerald-800",
  seller_confirmed: "border-teal-200 bg-teal-50 text-teal-800",
  needs_confirmation: "border-amber-200 bg-amber-50 text-amber-800",
  missing: "border-red-200 bg-red-50 text-red-800",
  invalid: "border-red-300 bg-red-100 text-red-900",
  conflict: "border-red-300 bg-red-100 text-red-900",
  unverified: "border-slate-200 bg-slate-50 text-slate-700",
  rejected: "border-red-300 bg-red-100 text-red-900"
};

const readinessStyles: Record<ReadinessStatus, string> = {
  ready_for_review: "border-emerald-200 bg-emerald-50 text-emerald-800",
  information_missing: "border-red-200 bg-red-50 text-red-800",
  specialist_review_required: "border-amber-200 bg-amber-50 text-amber-800"
};

const labels: Record<string, string> = {
  supported: "Supported by evidence",
  seller_confirmed: "Seller confirmed",
  needs_confirmation: "Needs confirmation",
  missing: "Missing",
  invalid: "Invalid",
  conflict: "Conflict",
  unverified: "Unverified",
  rejected: "Rejected",
  ready_for_review: "Ready for review",
  information_missing: "Missing information",
  specialist_review_required: "Specialist review",
  removed: "Removed",
  requires_confirmation: "Needs confirmation"
};

interface Props {
  status: EvidenceStatus | ReadinessStatus | "removed" | "requires_confirmation";
  label?: string;
}

export function StatusBadge({ status, label }: Props) {
  const t = useT();
  const className = status in evidenceStyles
    ? evidenceStyles[status as EvidenceStatus]
    : status in readinessStyles
      ? readinessStyles[status as ReadinessStatus]
      : status === "removed"
        ? "border-red-200 bg-red-50 text-red-800"
        : "border-amber-200 bg-amber-50 text-amber-800";

  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold ${className}`}>
      {t(label ?? labels[status] ?? status.split("_").join(" "))}
    </span>
  );
}
