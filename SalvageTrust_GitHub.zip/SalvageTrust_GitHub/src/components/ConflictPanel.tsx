import { AlertTriangle, CheckCircle2 } from "lucide-react";
import type { PartRecord } from "../types/salvage";
import { detectConflicts } from "../lib/conflictDetector";
import { summarizeTrust } from "../lib/trustEngine";

interface Props {
  part: PartRecord;
}

export function ConflictPanel({ part }: Props) {
  const conflicts = detectConflicts(part);
  const trust = summarizeTrust(part);

  return (
    <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-5 shadow-card backdrop-blur-xl">
      <div className="flex items-center gap-3">
        <div className="rounded-2xl bg-amber-400/10 p-3 text-amber-200">
          <AlertTriangle size={22} />
        </div>
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.24em] text-amber-300">Focused Questions</p>
          <h2 className="text-xl font-bold text-white">Resolve only what blocks trust</h2>
        </div>
      </div>

      <div className="mt-5 space-y-3">
        {conflicts.length === 0 && trust.missing.length === 0 && trust.needsConfirmation.length === 0 ? (
          <div className="flex items-center gap-3 rounded-2xl border border-emerald-400/20 bg-emerald-400/10 p-4 text-emerald-100">
            <CheckCircle2 size={20} /> No blocking questions. Seller can review the listing draft.
          </div>
        ) : null}

        {conflicts.map((conflict) => (
          <article key={conflict.field} className="rounded-2xl border border-red-400/20 bg-red-500/10 p-4">
            <p className="font-semibold text-red-100">Conflict: {conflict.label}</p>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {conflict.values.map((item) => (
                <button key={`${item.value}-${item.source.id}`} className="cursor-pointer rounded-xl border border-white/10 bg-slate-950/50 p-3 text-start transition hover:border-cyan-300/50">
                  <p className="text-lg font-bold text-white">{item.value}</p>
                  <p className="text-xs text-slate-400">{item.source.label}: {item.source.snippet}</p>
                </button>
              ))}
            </div>
            <p className="mt-3 text-sm text-slate-300">Ask seller: {conflict.question}</p>
          </article>
        ))}

        {trust.missing.map((attribute) => (
          <article key={attribute.field} className="rounded-2xl border border-red-400/20 bg-red-500/10 p-4">
            <p className="font-semibold text-red-100">Missing: {attribute.label}</p>
            <p className="mt-1 text-sm text-slate-300">Action: capture this before making any claim in the eBay draft.</p>
          </article>
        ))}

        {trust.needsConfirmation.map((attribute) => (
          <article key={attribute.field} className="rounded-2xl border border-amber-400/20 bg-amber-400/10 p-4">
            <p className="font-semibold text-amber-100">Needs confirmation: {attribute.label}</p>
            <p className="mt-1 text-sm text-slate-300">{attribute.value}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
