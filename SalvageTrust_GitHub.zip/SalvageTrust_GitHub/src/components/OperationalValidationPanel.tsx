import { CheckCircle2, CircleAlert, CircleX, ShieldCheck } from "lucide-react";
import type { ListingDraft } from "../types/salvage";
import { StatusBadge } from "./StatusBadge";

interface Props {
  draft: ListingDraft;
}

const actionFor = (status: string) => {
  if (status === "supported") return "Keep in draft";
  if (status === "removed") return "Remove claim until reference evidence exists";
  if (status === "requires_confirmation") return "Ask seller to confirm and record source";
  return "Label as unverified";
};

const iconFor = (status: string) => {
  if (status === "supported") return <CheckCircle2 size={18} className="text-emerald-300" />;
  if (status === "removed") return <CircleX size={18} className="text-red-300" />;
  return <CircleAlert size={18} className="text-amber-300" />;
};

export function OperationalValidationPanel({ draft }: Props) {
  return (
    <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-5 shadow-card backdrop-blur-xl">
      <div className="flex items-center gap-3">
        <div className="rounded-2xl bg-cyan-300/10 p-3 text-cyan-200">
          <ShieldCheck size={22} />
        </div>
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.22em] text-cyan-300">Validation Results</p>
          <h2 className="text-xl font-bold text-white">FitGuard review for listing claims</h2>
        </div>
      </div>

      <div className="mt-5 overflow-hidden rounded-2xl border border-white/10">
        <div className="grid grid-cols-[1.15fr_0.65fr_1fr_0.9fr] bg-slate-950/70 px-4 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-slate-400">
          <span>Claim</span>
          <span>Result</span>
          <span>Reason</span>
          <span>Action</span>
        </div>
        <div className="divide-y divide-white/10">
          {draft.claims.map((claim) => (
            <article key={claim.text} className="grid grid-cols-1 gap-3 bg-slate-950/35 px-4 py-4 text-sm md:grid-cols-[1.15fr_0.65fr_1fr_0.9fr]">
              <div className="flex gap-2 text-white">
                {iconFor(claim.status)}
                <span>{claim.text}</span>
              </div>
              <div><StatusBadge status={claim.status} /></div>
              <p className="text-slate-300">{claim.reason}</p>
              <p className="font-medium text-cyan-100">{actionFor(claim.status)}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
