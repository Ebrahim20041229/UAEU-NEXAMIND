import { ShieldCheck, Trash2 } from "lucide-react";
import { useT } from "../i18n/locale";
export function PrivacyPanel({onClear}:{onClear:()=>void}) {
 const t=useT();
 return <section className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-teal-200 bg-teal-50 px-4 py-3 text-sm">
 <div className="flex items-start gap-2"><ShieldCheck size={19} className="mt-0.5 shrink-0 text-teal-700"/><div><p className="font-semibold text-teal-900">{t("Private local session")}</p><p className="text-xs text-teal-800">{t("Files stay in this browser session. No uploads to a server. No inventory saved permanently.")}</p></div></div>
 <button type="button" onClick={onClear} className="inline-flex items-center gap-2 rounded-lg border border-teal-300 bg-white px-3 py-2 text-xs font-semibold text-teal-900"><Trash2 size={14}/>{t("Clear session data")}</button>
 </section>;
}
