import { ClipboardCheck, LockKeyhole, Truck } from "lucide-react";
import type { ReadinessResult } from "../types/salvage";
import { StatusBadge } from "./StatusBadge";

interface Props {
  readiness: ReadinessResult;
}

export function ReadinessChecklist({ readiness }: Props) {
  return (
    <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-5 shadow-card backdrop-blur-xl">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="rounded-2xl bg-teal-400/10 p-3 text-teal-200">
            <ClipboardCheck size={22} />
          </div>
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.24em] text-teal-300">Readiness Checklist</p>
            <h2 className="text-xl font-bold text-white">Clear next steps, not customs/legal clearance</h2>
          </div>
        </div>
        <StatusBadge status={readiness.status} />
      </div>

      <div className="mt-5 grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border border-white/10 bg-slate-950/50 p-4">
          <LockKeyhole className="text-cyan-300" size={20} />
          <p className="mt-2 text-3xl font-bold text-white">{readiness.score}%</p>
          <p className="text-sm text-slate-400">Evidence trust score</p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-slate-950/50 p-4">
          <Truck className="text-amber-300" size={20} />
          <p className="mt-2 text-3xl font-bold text-white">UAE → UK</p>
          <p className="text-sm text-slate-400">Test corridor checklist only</p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-slate-950/50 p-4">
          <ClipboardCheck className="text-emerald-300" size={20} />
          <p className="mt-2 text-3xl font-bold text-white">Seller</p>
          <p className="text-sm text-slate-400">Final approval required</p>
        </div>
      </div>

      <div className="mt-5 space-y-2">
        {readiness.actions.map((action) => (
          <div key={action} className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-slate-200">
            <span className="h-2 w-2 rounded-full bg-cyan-300" /> {action}
          </div>
        ))}
      </div>
    </section>
  );
}
