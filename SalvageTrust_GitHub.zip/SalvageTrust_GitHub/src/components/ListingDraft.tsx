import { FileText, ShieldCheck } from "lucide-react";
import type { ListingDraft as Draft } from "../types/salvage";
import { StatusBadge } from "./StatusBadge";

interface Props {
  draft: Draft;
}

export function ListingDraft({ draft }: Props) {
  return (
    <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-5 shadow-card backdrop-blur-xl">
      <div className="flex items-center gap-3">
        <div className="rounded-2xl bg-blue-500/10 p-3 text-cyan-200">
          <FileText size={22} />
        </div>
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.24em] text-cyan-300">Safe eBay Draft</p>
          <h2 className="text-xl font-bold text-white">Editable listing with claim-level evidence</h2>
        </div>
      </div>

      <div className="mt-5 rounded-2xl border border-white/10 bg-slate-950/60 p-4">
        <p className="text-xs uppercase tracking-[0.2em] text-slate-500">Title</p>
        <h3 className="mt-1 text-xl font-bold text-white">{draft.title}</h3>
        <p className="mt-3 text-sm text-slate-300">{draft.description}</p>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-2">
        {draft.itemSpecifics.map((specific) => (
          <div key={specific.label} className="rounded-2xl border border-white/10 bg-slate-950/40 p-3">
            <div className="flex items-center justify-between gap-3">
              <p className="text-sm text-slate-400">{specific.label}</p>
              <StatusBadge status={specific.status} />
            </div>
            <p className="mt-1 font-semibold text-white">{specific.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-5 space-y-3">
        {draft.claims.map((claim) => (
          <article key={claim.text} className="rounded-2xl border border-white/10 bg-slate-950/50 p-4">
            <div className="flex flex-wrap items-center gap-2">
              <ShieldCheck size={16} className="text-cyan-300" />
              <StatusBadge status={claim.status} />
              <span className="text-xs uppercase tracking-[0.18em] text-slate-500">{claim.claimType}</span>
            </div>
            <p className="mt-2 font-medium text-white">{claim.text}</p>
            <p className="mt-1 text-sm text-slate-400">{claim.reason}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
