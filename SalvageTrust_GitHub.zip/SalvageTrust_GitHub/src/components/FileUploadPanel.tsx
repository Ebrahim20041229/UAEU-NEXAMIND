import { FileSpreadsheet, ImageUp, UploadCloud } from "lucide-react";
import type { ParsedCsv, UploadedImage } from "../types/salvage";

interface Props {
  images: UploadedImage[];
  csv: ParsedCsv | null;
  onImagesSelected: (files: FileList | null) => void;
  onCsvSelected: (file: File | null) => void;
}

const formatBytes = (bytes: number) => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
};

export function FileUploadPanel({ images, csv, onImagesSelected, onCsvSelected }: Props) {
  return (
    <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-5 shadow-card backdrop-blur-xl">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.22em] text-cyan-300">Upload workspace</p>
          <h2 className="mt-1 text-2xl font-bold text-white">Process real seller files</h2>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-300">
            Upload part photos and a simple inventory CSV. The browser reads file names, sizes, image previews, and CSV rows locally.
          </p>
        </div>
        <UploadCloud className="text-cyan-300" size={30} />
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <label className="group flex cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-cyan-300/30 bg-slate-950/50 p-6 text-center transition hover:border-cyan-300/70 hover:bg-cyan-300/5">
          <ImageUp className="text-cyan-300" size={28} />
          <span className="mt-3 font-semibold text-white">Upload part images</span>
          <span className="mt-1 text-sm text-slate-400">JPG, PNG, or WebP · multiple files</span>
          <input
            className="sr-only"
            type="file"
            accept="image/jpeg,image/png,image/webp"
            multiple
            onChange={(event) => onImagesSelected(event.target.files)}
          />
        </label>

        <label className="group flex cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-teal-300/30 bg-slate-950/50 p-6 text-center transition hover:border-teal-300/70 hover:bg-teal-300/5">
          <FileSpreadsheet className="text-teal-300" size={28} />
          <span className="mt-3 font-semibold text-white">Upload inventory CSV</span>
          <span className="mt-1 text-sm text-slate-400">Headers like part_number, donor_vehicle, condition</span>
          <input
            className="sr-only"
            type="file"
            accept=".csv,text/csv"
            onChange={(event) => onCsvSelected(event.target.files?.[0] ?? null)}
          />
        </label>
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-white/10 bg-slate-950/40 p-4">
          <div className="mb-3 flex items-center justify-between">
            <p className="font-semibold text-white">Images processed</p>
            <span className="rounded-full bg-cyan-300/10 px-3 py-1 text-xs font-semibold text-cyan-200">{images.length} file(s)</span>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {images.map((image) => (
              <article key={image.id} className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                <img src={image.previewUrl} alt={image.name} className="h-24 w-full rounded-lg object-contain" />
                <p className="mt-2 truncate text-sm font-semibold text-white">{image.name}</p>
                <p className="text-xs text-slate-400">{image.type} · {formatBytes(image.size)}</p>
              </article>
            ))}
            {images.length === 0 ? <p className="text-sm text-slate-400">No images uploaded yet.</p> : null}
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-slate-950/40 p-4">
          <div className="mb-3 flex items-center justify-between">
            <p className="font-semibold text-white">CSV processed</p>
            <span className="rounded-full bg-teal-300/10 px-3 py-1 text-xs font-semibold text-teal-200">{csv ? `${csv.rows.length} row(s)` : "No CSV"}</span>
          </div>
          {csv ? (
            <div className="space-y-2 text-sm text-slate-300">
              <p><span className="text-slate-500">File:</span> {csv.fileName}</p>
              <p><span className="text-slate-500">Columns:</span> {csv.headers.join(", ") || "No headers"}</p>
            </div>
          ) : (
            <p className="text-sm text-slate-400">Upload a CSV to prefill the evidence form.</p>
          )}
        </div>
      </div>
    </section>
  );
}
