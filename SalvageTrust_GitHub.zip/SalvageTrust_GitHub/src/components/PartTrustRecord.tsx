import { Database, Image, Languages, Sheet, Wrench } from "lucide-react";
import type { EvidenceSource, PartRecord } from "../types/salvage";
import { sourceLine } from "../lib/trustEngine";
import { StatusBadge } from "./StatusBadge";

const iconFor = (type: EvidenceSource["type"]) => {
  if (type === "photo") return <Image size={14} />;
  if (type === "spreadsheet") return <Sheet size={14} />;
  if (type === "arabic_note") return <Languages size={14} />;
  if (type === "reference_db") return <Database size={14} />;
  return <Wrench size={14} />;
};

interface Props {
  part: PartRecord;
}

export function PartTrustRecord({ part }: Props) {
  return (
    <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-5 shadow-card backdrop-blur-xl">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.24em] text-teal-300">Trust Record</p>
          <h2 className="mt-1 text-2xl font-bold text-white">{part.title}</h2>
          <p className="mt-2 text-sm text-slate-300">Every value below keeps its evidence source. No source means no claim.</p>
        </div>
        <div className="flex h-28 w-full items-center justify-center rounded-2xl border border-cyan-300/20 bg-gradient-to-br from-slate-950 via-blue-950 to-teal-900 text-center shadow-glow lg:w-44">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-cyan-200">Evidence photos</p>
            <p className="mt-1 text-lg font-extrabold text-white">{part.id}</p>
          </div>
        </div>
      </div>

      <div className="mt-5 grid gap-3 md:grid-cols-2">
        {part.attributes.map((attribute) => (
          <article key={attribute.field} className="rounded-2xl border border-white/10 bg-slate-950/50 p-4 transition hover:border-cyan-300/30">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-sm font-semibold text-slate-200">{attribute.label}</p>
                <p className="mt-1 text-lg font-bold text-white">{attribute.value ?? "Not captured yet"}</p>
              </div>
              <StatusBadge status={attribute.status} />
            </div>
            <p className="mt-3 text-xs text-slate-400">{sourceLine(attribute)}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {attribute.sources.map((source) => (
                <span key={source.id} className="inline-flex items-center gap-1 rounded-full bg-white/5 px-2 py-1 text-xs text-slate-300">
                  {iconFor(source.type)} {source.label}
                </span>
              ))}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
