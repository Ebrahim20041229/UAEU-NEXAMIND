import { useT } from "../i18n/locale";
import { Loader2, PackageSearch } from "lucide-react";
import type { EditableListingDraft, ProductFieldKey, ProductWorkspaceRecord, UploadedImage } from "../types/salvage";
import { primaryFieldKeys, secondaryFieldKeys } from "../lib/productAnalysis";
import { CompactReviewSummary } from "./CompactReviewSummary";
import { EvidenceFieldCard } from "./EvidenceFieldCard";
import { ListingDraftDrawer } from "./ListingDraftDrawer";

interface Props {
  product?: ProductWorkspaceRecord;
  images: UploadedImage[];
  draftOpen: boolean;
  updated: boolean;
  onAnalyze: () => void;
  onViewDraft: () => void;
  onFieldChange: (key: ProductFieldKey, value: string) => void;
  onConfirm: (key: ProductFieldKey) => void;
  onNeedsReview: (key: ProductFieldKey) => void;
  onReject: (key: ProductFieldKey) => void;
  onDraftChange: (draft: EditableListingDraft) => void;
  onApproveDraft: () => void;
}

export function ReviewWorkspace({ product, images, draftOpen, updated, onAnalyze, onViewDraft, onFieldChange, onConfirm, onNeedsReview, onReject, onDraftChange, onApproveDraft }: Props) {
  const t = useT();
  if (!product) {
    return <EmptyState message={t("Upload files and select a product to begin.")} />;
  }

  if (product.analysisState === "analyzing") {
    return <EmptyState message={t("Analyzing selected evidence...")} loading />;
  }

  const productImages = images.filter((image) => product.imageIds.includes(image.id));
  const showReview = product.analysisState === "analyzed" || product.analysisState === "error";

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-bold text-[#172B4D]">{t("Review selected product")}</h2>
          <p className="text-sm text-slate-600">{product.displayName}</p>
          {updated && <p className="mt-1 text-sm font-semibold text-teal-700">{t("Updated")}</p>}
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={onAnalyze} className="rounded-lg bg-[#0F766E] px-4 py-2 text-sm font-semibold text-white hover:bg-[#115E59] focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2">{t("Analyze product")}</button>
          <button type="button" onClick={onViewDraft} disabled={!product.draft} className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50 focus:outline-none focus:ring-2 focus:ring-teal-600">{t("View listing draft")}</button>
        </div>
      </div>

      {!showReview && (
        <div className="mt-5 rounded-xl border border-dashed border-slate-300 bg-[#F7F9FC] p-6 text-center text-sm text-slate-600">{t("Select Analyze product to review evidence and create a safe draft. Uploading files alone does not start analysis.")}</div>
      )}

      {product.analysisState === "error" && <p className="mt-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-800">{product.error ?? "Analysis failed. Check sources and retry."}</p>}

      {showReview && (
        <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_280px]">
          <div className="space-y-5">
            <div className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {productImages.length ? productImages.map((image) => (
                  <figure key={image.id} className="overflow-hidden rounded-xl border border-slate-200 bg-slate-50">
                    <img src={image.previewUrl} alt={image.name} className="h-44 w-full object-contain" />
                    <figcaption className="truncate p-2 text-xs text-slate-600">{image.name}</figcaption>
                  </figure>
                )) : <div className="flex h-44 items-center justify-center rounded-xl border border-dashed border-slate-300 bg-slate-50 text-sm text-slate-500">{t("No matched image")}</div>}
              </div>
              {product.matchIssue && <p className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">{t(product.matchIssue)}</p>}
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              {primaryFieldKeys.map((key) => (
                <EvidenceFieldCard key={`${product.id}:${key}`} field={product.fields[key]} onChange={onFieldChange} onConfirm={onConfirm} onNeedsReview={onNeedsReview} onReject={onReject} />
              ))}
            </div>

            <details className="rounded-xl border border-slate-200 bg-white p-4">
              <summary className="cursor-pointer font-semibold text-[#172B4D]">{t("More details")}</summary>
              <div className="mt-4 grid gap-3 md:grid-cols-2">
                {secondaryFieldKeys.map((key) => (
                  <EvidenceFieldCard key={`${product.id}:${key}`} field={product.fields[key]} onChange={onFieldChange} onConfirm={onConfirm} onNeedsReview={onNeedsReview} onReject={onReject} />
                ))}
              </div>
            </details>

            {product.draft && <ListingDraftDrawer open={draftOpen} product={product} draft={product.draft} images={images} onChange={onDraftChange} onApprove={onApproveDraft} />}
          </div>
          <CompactReviewSummary product={product} />
        </div>
      )}
    </section>
  );
}

function EmptyState({ message, loading = false }: { message: string; loading?: boolean }) {
  const t = useT();
  return (
    <section className="rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center shadow-sm">
      {loading ? <Loader2 className="mx-auto animate-spin text-teal-700" size={28} /> : <PackageSearch className="mx-auto text-slate-400" size={28} />}
      <p className="mt-3 text-sm text-slate-600">{t(message)}</p>
    </section>
  );
}
