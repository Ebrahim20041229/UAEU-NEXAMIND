import { useState } from "react";
import { generateWorkspaceDraft } from "../lib/listingGenerator";
import { useT } from "../i18n/locale";
import { CheckCircle2, Clipboard, Download } from "lucide-react";
import type { EditableListingDraft, ProductWorkspaceRecord, UploadedImage } from "../types/salvage";
import { StatusBadge } from "./StatusBadge";

interface Props {
  open: boolean;
  product: ProductWorkspaceRecord;
  draft: EditableListingDraft;
  images: UploadedImage[];
  onChange: (draft: EditableListingDraft) => void;
  onApprove: () => void;
}

export function ListingDraftDrawer({ open, product, draft, images, onChange, onApprove }: Props) {
  const t = useT();
  const [notice,setNotice] = useState("");
  if (!open) return null;

  const exportDraft = () => {
    const body = `${draft.title}\n\n${draft.description}\n\nCategory: ${draft.category}\nCompatibility: ${draft.compatibilityDisclosure}`;
    const blob = new Blob([body], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${product.id}-ebay-draft.txt`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const copyDraft = async () => { try { await navigator.clipboard.writeText(`${draft.title}\n\n${draft.description}`); setNotice("Copied successfully"); } catch { setNotice("Copy failed. Use Export draft instead."); } };

  return (
    <section className="mt-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="text-lg font-bold text-[#172B4D]">{t("Listing draft")}</h3>
          <p className="text-sm text-slate-600">{t("Editable preview. Compatibility is limited to supported evidence.")}</p>
        </div>
        <StatusBadge status={product.approvalStatus === "seller_approved" ? "seller_confirmed" : "needs_confirmation"} label={t(product.approvalStatus === "seller_approved" ? "Seller approved" : "Seller review needed")} />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[180px_1fr]">
        <div className="overflow-hidden rounded-xl border border-slate-200 bg-slate-50">
          {product.imageIds.length ? <ProductImage product={product} images={images} /> : <div className="flex h-40 items-center justify-center text-sm text-slate-500">{t("No image matched")}</div>}
        </div>
        <div className="space-y-3">
          <label className="block text-sm font-semibold text-[#172B4D]">{t("Title")}</label>
          <input value={draft.title} onChange={(event) => onChange({ ...draft, manuallyEdited:true, title: event.target.value })} className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-[#172B4D] outline-none focus:ring-2 focus:ring-teal-600" />
          <label className="block text-sm font-semibold text-[#172B4D]">{t("Description")}</label>
          <textarea value={draft.description} onChange={(event) => onChange({ ...draft, manuallyEdited:true, description: event.target.value })} rows={5} className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-[#172B4D] outline-none focus:ring-2 focus:ring-teal-600" />
          <div className="grid gap-3 sm:grid-cols-2">
            <Info label={t("Suggested category")} value={draft.category} />
            <Info label={t("Compatibility")} value={draft.compatibilityDisclosure} />
            <Info label={t("Condition")} value={draft.conditionDisclosure} />
            <Info label={t("Testing")} value={draft.testingDisclosure} />
          </div>
        </div>
      </div>

      <div className="mt-4 rounded-xl border border-slate-200 bg-[#F7F9FC] p-3">
        <p className="text-sm font-semibold text-[#172B4D]">{t("Item specifics")}</p>
        <div className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {draft.itemSpecifics.map((item) => <Info key={item.label} label={item.label} value={item.value} />)}
        </div>
      </div>

      {draft.manuallyEdited && <div className="mt-3 rounded-lg bg-amber-50 p-3 text-sm"><p>{t("Manual draft preserved. Regenerate to use current product values.")}</p><button type="button" className="mt-2 rounded-lg border px-3 py-2" onClick={() => onChange({...generateWorkspaceDraft(product,[]),manuallyEdited:false})}>{t("Regenerate draft")}</button></div>}
      {notice && <p role="status">{t(notice)}</p>}
      <div className="mt-4 flex flex-wrap gap-2">
        <button type="button" onClick={copyDraft} className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-teal-600"><Clipboard size={16} />{t("Copy draft")}</button>
        <button type="button" onClick={exportDraft} className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-teal-600"><Download size={16} />{t("Export draft")}</button>
        <button type="button" onClick={onApprove} className="inline-flex items-center gap-2 rounded-lg bg-[#0F766E] px-4 py-2 text-sm font-semibold text-white hover:bg-[#115E59] focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2"><CheckCircle2 size={16} />{t("Seller review complete")}</button>
      </div>
    </section>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  const t = useT();
  return <div className="rounded-lg bg-white p-3 text-sm"><p className="font-semibold text-slate-500">{t(label)}</p><p className="mt-1 text-[#172B4D]">{t(value)}</p></div>;
}

function ProductImage({ product, images }: { product: ProductWorkspaceRecord; images: UploadedImage[] }) {
  const t = useT();
  const image = images.find((item) => product.imageIds.includes(item.id));
  if (!image) return <div className="flex h-40 items-center justify-center text-sm text-slate-500">{t("No image matched")}</div>;
  return <img src={image.previewUrl} alt={image.name} className="h-40 w-full object-contain" />;
}
