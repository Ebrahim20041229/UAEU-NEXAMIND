import { AlertTriangle, CheckCircle2, ShieldCheck } from "lucide-react";
import type { PartRecord } from "../types/salvage";
import { classifyReadiness } from "../lib/readiness";
import { summarizeTrust } from "../lib/trustEngine";
import { StatusBadge } from "./StatusBadge";

interface Props {
  parts: PartRecord[];
  selectedId: string;
  onSelect: (id: string) => void;
}

export function Dashboard({ parts, selectedId, onSelect }: Props) {
  return (
    <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-5 shadow-card backdrop-blur-xl">
      <div className="mb-5 flex items-center justify-between gap-4">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.24em] text-cyan-300">B2B Inventory</p>
          <h2 className="mt-1 text-2xl font-bold text-white">10 side-view mirrors ready for trust review</h2>
        </div>
        <div className="rounded-2xl border border-cyan-300/20 bg-cyan-300/10 px-4 py-3 text-end">
          <p className="text-xs text-slate-300">Return risk focus</p>
          <p className="text-lg font-bold text-cyan-200">Fitment claims</p>
        </div>
      </div>

      <div className="grid gap-3 lg:grid-cols-2">
        {parts.map((part) => {
          const readiness = classifyReadiness(part);
          const trust = summarizeTrust(part);
          const selected = selectedId === part.id;
          return (
            <button
              key={part.id}
              onClick={() => onSelect(part.id)}
              className={`group flex cursor-pointer items-center gap-4 rounded-2xl border p-4 text-start transition duration-300 hover:-translate-y-1 hover:border-cyan-300/50 hover:bg-white/[0.07] ${
                selected ? "border-cyan-300/70 bg-cyan-300/10 shadow-glow" : "border-white/10 bg-slate-950/40"
              }`}
            >
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-teal-400 text-white shadow-glow">
                {readiness.status === "ready_for_review" ? <CheckCircle2 size={22} /> : readiness.status === "information_missing" ? <AlertTriangle size={22} /> : <ShieldCheck size={22} />}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="truncate font-semibold text-white">{part.id}</p>
                  <StatusBadge status={readiness.status} />
                </div>
                <p className="mt-1 truncate text-sm text-slate-300">{part.title}</p>
                <div className="mt-3 flex items-center gap-3 text-xs text-slate-400">
                  <span>{trust.issueCount} issues</span>
                  <span>{trust.score}% trust</span>
                  <span>{part.price}</span>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}
