import type { ParsedCsv } from "../types/salvage";

interface Props {
  csv: ParsedCsv | null;
  selectedRow: number;
  onSelectRow: (index: number) => void;
}

export function CsvPreview({ csv, selectedRow, onSelectRow }: Props) {
  if (!csv) {
    return (
      <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-5 shadow-card backdrop-blur-xl">
        <p className="text-sm font-semibold uppercase tracking-[0.22em] text-slate-400">CSV Preview</p>
        <p className="mt-3 text-slate-300">No CSV has been uploaded. The evidence form remains editable manually.</p>
      </section>
    );
  }

  const visibleHeaders = csv.headers.slice(0, 8);
  const visibleRows = csv.rows.slice(0, 5);

  return (
    <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-5 shadow-card backdrop-blur-xl">
      <div className="flex items-center justify-between gap-4">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.22em] text-teal-300">CSV Preview</p>
          <h2 className="mt-1 text-xl font-bold text-white">{csv.fileName}</h2>
        </div>
        <span className="rounded-full border border-teal-300/20 bg-teal-300/10 px-3 py-1 text-xs font-semibold text-teal-200">
          {csv.rows.length} row(s)
        </span>
      </div>

      <div className="mt-4 overflow-hidden rounded-2xl border border-white/10">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[680px] border-collapse text-start text-sm">
            <thead className="bg-slate-950/70 text-slate-300">
              <tr>
                <th className="px-3 py-3">Use</th>
                {visibleHeaders.map((header) => <th key={header} className="px-3 py-3 font-semibold">{header}</th>)}
              </tr>
            </thead>
            <tbody>
              {visibleRows.map((row, index) => (
                <tr key={index} className={selectedRow === index ? "bg-cyan-300/10" : "bg-slate-950/30"}>
                  <td className="px-3 py-3">
                    <button
                      type="button"
                      onClick={() => onSelectRow(index)}
                      className="cursor-pointer rounded-lg border border-cyan-300/30 px-3 py-1 text-xs font-semibold text-cyan-200 transition hover:bg-cyan-300/10"
                    >
                      Select
                    </button>
                  </td>
                  {visibleHeaders.map((header) => <td key={header} className="max-w-[180px] truncate px-3 py-3 text-slate-300">{row[header] || "—"}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
