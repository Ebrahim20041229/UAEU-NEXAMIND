import type { EvidenceFormState } from "../types/salvage";

interface Props {
  value: EvidenceFormState;
  onChange: (value: EvidenceFormState) => void;
}

type Field = {
  key: keyof EvidenceFormState;
  label: string;
  placeholder: string;
  type?: "text" | "number";
};

const fields: Field[] = [
  { key: "partType", label: "Part type", placeholder: "Side-view mirror" },
  { key: "manufacturer", label: "Manufacturer", placeholder: "Toyota" },
  { key: "partNumber", label: "Part number", placeholder: "87940-02A10" },
  { key: "donorVehicle", label: "Donor vehicle", placeholder: "Toyota Corolla" },
  { key: "donorYear", label: "Donor year", placeholder: "2018" },
  { key: "position", label: "Position", placeholder: "Left / Right" },
  { key: "condition", label: "Condition", placeholder: "Used, light scratches, no broken tabs" },
  { key: "testingStatus", label: "Testing status", placeholder: "Tested working / Not recorded" },
  { key: "weight", label: "Weight", placeholder: "1.4 kg" },
  { key: "dimensions", label: "Dimensions", placeholder: "34 x 22 x 18 cm" },
  { key: "price", label: "Asking price", placeholder: "$45" },
  { key: "location", label: "Storage location", placeholder: "Rack B-12" }
];

export function EvidenceForm({ value, onChange }: Props) {
  const update = (key: keyof EvidenceFormState, fieldValue: string) => {
    onChange({ ...value, [key]: fieldValue });
  };

  return (
    <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-5 shadow-card backdrop-blur-xl">
      <div className="flex flex-col gap-2">
        <p className="text-sm font-semibold uppercase tracking-[0.22em] text-cyan-300">Evidence form</p>
        <h2 className="text-2xl font-bold text-white">Complete only what the files cannot prove</h2>
        <p className="text-sm leading-6 text-slate-300">
          Values from CSV can be corrected here. Images are attached as evidence, but this version does not claim computer-vision damage detection.
        </p>
      </div>

      <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {fields.map((field) => (
          <label key={field.key} className="flex flex-col gap-2">
            <span className="text-sm font-semibold text-slate-200">{field.label}</span>
            <input
              type={field.type ?? "text"}
              value={value[field.key]}
              placeholder={field.placeholder}
              onChange={(event) => update(field.key, event.target.value)}
              className="rounded-2xl border border-white/10 bg-slate-950/60 px-4 py-3 text-sm text-white outline-none transition placeholder:text-slate-600 focus:border-cyan-300/60 focus:bg-slate-950"
            />
          </label>
        ))}
      </div>
    </section>
  );
}
