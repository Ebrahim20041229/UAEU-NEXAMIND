import { useT } from "../i18n/locale";
import type { ReadinessStatus, StatusFilter, WorkspaceSummary } from "../types/salvage";

const money = (values: Record<string, number>) => {
  const entries = Object.entries(values);
  if (!entries.length) return "AED 0";
  return entries.map(([currency, value]) => `${currency} ${value.toLocaleString()}`).join(" · ");
};

const cards: { key: StatusFilter; title: string; value: keyof Pick<WorkspaceSummary, "total" | "missing" | "specialist" | "ready">; accent: string; detail: (summary: WorkspaceSummary) => string }[] = [
  { key: "all", title: "Total parts", value: "total", accent: "bg-slate-100 text-slate-700", detail: (summary) => `Total asking value ${money(summary.inventoryValueByCurrency)}` },
  { key: "information_missing", title: "Missing information", value: "missing", accent: "bg-red-50 text-red-800", detail: (summary) => summary.nextProductId ? `Next action ${summary.nextProductId}` : "No open priority" },
  { key: "specialist_review_required", title: "Specialist review", value: "specialist", accent: "bg-amber-50 text-amber-800", detail: () => "for_parts or policy review" },
  { key: "ready_for_review", title: "Ready for review", value: "ready", accent: "bg-emerald-50 text-emerald-800", detail: (summary) => `Ready value ${money(summary.readyValueByCurrency)}` }
];

interface Props {
  summary: WorkspaceSummary;
  activeFilter: StatusFilter;
  onFilter: (filter: StatusFilter) => void;
}

export function SummaryCards({ summary, activeFilter, onFilter }: Props) {
  const t = useT();
  return (
    <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4" aria-label={t("Product status summary")}>
      {cards.map((card) => {
        const active = activeFilter === card.key;
        return (
          <button
            type="button"
            key={card.key}
            onClick={() => onFilter(card.key)}
            className={`rounded-xl border bg-white p-4 text-start shadow-sm transition hover:-translate-y-0.5 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-teal-600 ${active ? "border-teal-600 ring-1 ring-teal-600" : "border-slate-200"}`}
          >
            <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${card.accent}`}>{t(card.title)}</span>
            <p className="mt-3 text-3xl font-bold text-[#172B4D]">{summary[card.value]}</p>
            <p className="mt-1 text-xs font-medium text-slate-500">{t(card.detail(summary))}</p>
            {card.key === "all" && <p className="mt-2 text-xs text-slate-500">{t("Colors:")}{summary.green}{t("green ·")}{summary.amber}{t("amber ·")}{summary.red}{t("red")}</p>}
          </button>
        );
      })}
    </section>
  );
}

export const statusMatchesFilter = (status: ReadinessStatus, filter: StatusFilter) => filter === "all" || status === filter;
