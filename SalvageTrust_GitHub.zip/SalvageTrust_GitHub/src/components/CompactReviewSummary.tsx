import { useT } from "../i18n/locale";
import { checklistMetadata } from "../data/checklistRules";
import type { ProductWorkspaceRecord } from "../types/salvage";
import { summarizeProduct } from "../lib/productAnalysis";
import { StatusBadge } from "./StatusBadge";

interface Props {
  product: ProductWorkspaceRecord;
}

export function CompactReviewSummary({ product }: Props) {
  const t = useT();
  const summary = summarizeProduct(product);
  return (
    <aside className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <p className="text-sm font-semibold text-slate-500">{t("Current readiness")}</p>
      <div className="mt-2"><StatusBadge status={product.readinessStatus} /></div>
      <div className="mt-3 rounded-lg bg-[#F7F9FC] p-3 text-sm">
        <p className="font-semibold text-[#172B4D]">{t("Rule result:")}{t(product.validationColor)}</p>
        <p className="mt-1 text-slate-600">{t("Checks passed:")}{product.checksPassedPercent}%</p>
        
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
        <div className="rounded-lg bg-emerald-50 p-2 text-emerald-800"><p className="text-lg font-bold">{summary.supported}</p><p className="text-xs">{t("Supported")}</p></div>
        <div className="rounded-lg bg-amber-50 p-2 text-amber-800"><p className="text-lg font-bold">{summary.needs}</p><p className="text-xs">{t("Confirm")}</p></div>
        <div className="rounded-lg bg-red-50 p-2 text-red-800"><p className="text-lg font-bold">{summary.issues}</p><p className="text-xs">{t("Issues")}</p></div>
      </div>
      <div className="mt-4 rounded-lg bg-[#F7F9FC] p-3">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{t("Next action")}</p>
        <p className="mt-1 text-sm text-[#172B4D]">{t(summary.nextAction)}</p>
      </div>
      <details className="mt-3 text-sm text-slate-600">
        <summary className="cursor-pointer font-semibold text-teal-700">{t("Checklist scope")}</summary>
        <p className="mt-2">{checklistMetadata.corridor} · {checklistMetadata.version} · {checklistMetadata.date}</p>
        <p>{t(checklistMetadata.note)}</p><p>{t("Demo data checks only; no image recognition or calibrated AI confidence.")}</p>
      </details>
    </aside>
  );
}
