import { LocaleProvider } from "./i18n/locale";
import { useEffect, useMemo, useRef, useState } from "react";
import { AppHeader } from "./components/AppHeader";
import { ManualAssociationPanel } from "./components/ManualAssociationPanel";
import { ProductSelector } from "./components/ProductSelector";
import { ReviewWorkspace } from "./components/ReviewWorkspace";
import { statusMatchesFilter, SummaryCards } from "./components/SummaryCards";
import { UploadWorkspace } from "./components/UploadWorkspace";
import { compatibilityReference } from "./data/compatibilityReference";
import { copy, directionFor } from "./i18n/copy";
import { MAX_CSV_BYTES, MAX_IMAGES, MAX_TOTAL_IMAGE_BYTES, validateImageFile } from "./lib/fileSecurity";
import { PrivacyPanel } from "./components/PrivacyPanel";
import { parseCsv } from "./lib/csvParser";
import { generateWorkspaceDraft } from "./lib/listingGenerator";
import { analyzeProduct, reviewContextFor, summarizeWorkspace } from "./lib/productAnalysis";
import { applyManualAssociation, buildProductsFromUploads } from "./lib/productImporter";
import { clearWorkspaceData, workspaceFingerprint, applyWorkspacePatches, loadWorkspacePatches, saveWorkspaceProducts } from "./lib/workspaceStorage";
import type { EditableListingDraft, EvidenceSource, InventorySourceCell, Language, ProductFieldKey, ProductWorkspaceRecord, StatusFilter, UploadedCsvFile, UploadedImage } from "./types/salvage";

const acceptedImageTypes = ["image/jpeg", "image/png", "image/webp"];
const isAcceptedImage = (file: File) => acceptedImageTypes.includes(file.type) || /\.(jpe?g|png|webp)$/i.test(file.name);

function App() {
  const [language, setLanguage] = useState<Language>(() => { try { return localStorage.getItem("salvagetrust.language") === "ar" ? "ar" : "en"; } catch { return "en"; } });
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [csvFiles, setCsvFiles] = useState<UploadedCsvFile[]>([]);
  const [csvError, setCsvError] = useState<string>();
  const [products, setProducts] = useState<ProductWorkspaceRecord[]>([]);
  const [selectedProductId, setSelectedProductId] = useState<string>();
  const [filter, setFilter] = useState<StatusFilter>("all");
  const [draftOpen, setDraftOpen] = useState(false);
  const [updatedProductId, setUpdatedProductId] = useState<string>();
  const operationEpoch = useRef(0);
  const csvReadRevision = useRef(0);
  const sourceSequence = useRef(0);
  useEffect(() => { clearWorkspaceData(); }, []);
  const uploadRef = useRef<HTMLDivElement>(null);

  const t = copy[language];

  const withDraft = (product: ProductWorkspaceRecord) => {
    const filenames = (product.fields.imageFilename.value ?? "").split(/[;,|\n]/).map(name => name.trim().toLowerCase()).filter(Boolean);
    const matched = images.filter(image => filenames.includes(image.name.toLowerCase()) || image.productId === product.id);
    const analyzed = analyzeProduct({...product,imageIds:matched.map(image => image.id), associatedFilenames:matched.map(image => image.name),matchIssue:matched.length ? undefined : product.matchIssue}, images);
    return { ...analyzed, draft: product.draft?.manuallyEdited ? product.draft : generateWorkspaceDraft(analyzed, compatibilityReference), approvalStatus: product.approvalStatus };
  };

  const imageUrls = useRef(new Set<string>());
  useEffect(() => { images.forEach(image => imageUrls.current.add(image.previewUrl)); }, [images]);
  useEffect(() => () => { imageUrls.current.forEach(url => URL.revokeObjectURL(url)); }, []);
  useEffect(() => { document.documentElement.lang = language; document.documentElement.dir = directionFor(language); try { localStorage.setItem("salvagetrust.language", language); } catch {} }, [language]);

  useEffect(() => {
    const imported = buildProductsFromUploads(csvFiles, images);
    const patched = applyWorkspacePatches(imported, loadWorkspacePatches()).map(product => ({...analyzeProduct(product,images), analysisState: product.draft ? "analyzed" as const : product.analysisState}));
    setProducts((current) => patched.map((product) => {
      const previous = current.find((item) => item.id === product.id);
      if (previous && workspaceFingerprint(previous) === workspaceFingerprint(product) && (previous.analysisState === "analyzed" || previous.draft)) {
        return withDraft({ ...product, draft: previous.draft ?? product.draft, approvalStatus: previous.approvalStatus });
      }
      return product;
    }));
    setSelectedProductId((current) => current && patched.some((product) => product.id === current) ? current : patched[0]?.id);
  }, [csvFiles, images]);

  useEffect(() => {
    if (products.length) saveWorkspaceProducts(products);
  }, [products]);

  const summary = useMemo(() => summarizeWorkspace(products), [products]);
  const filteredProducts = useMemo(() => products.filter((product) => statusMatchesFilter(product.readinessStatus, filter)), [products, filter]);
  const selectedProduct = products.find((product) => product.id === selectedProductId);

  const markUpdated = (productId: string) => {
    setUpdatedProductId(productId);
    window.setTimeout(() => setUpdatedProductId((current) => current === productId ? undefined : current), 1400);
  };

  const updateProduct = (productId: string, updater: (product: ProductWorkspaceRecord) => ProductWorkspaceRecord) => {
    setProducts((current) => current.map((product) => product.id === productId ? updater(product) : product));
    markUpdated(productId);
  };

  const handleImagesSelected = async (files: FileList | File[] | null) => {
    const candidates = Array.from(files ?? []);
    const epoch = operationEpoch.current;
    if (images.length + candidates.length > MAX_IMAGES || images.reduce((n,f) => n+f.size,0) + candidates.reduce((n,f) => n+f.size,0) > MAX_TOTAL_IMAGE_BYTES) {
      setCsvError("Image upload limit: 50 images and 100 MB total."); return;
    }
    try {
      const checks = await Promise.all(candidates.map(validateImageFile));
      if (epoch !== operationEpoch.current) return;
      if (checks.some(valid => !valid)) { setCsvError("Use genuine JPG, PNG or WebP images, up to 10 MB each. SVG and renamed files are rejected."); return; }
      const uploaded = candidates.map(file => ({id:`${file.name}-${file.lastModified}-${file.size}`,name:file.name,type:file.type,size:file.size,previewUrl:URL.createObjectURL(file),matchStatus:"unmatched" as const}));
      setImages(current => {
        const existing = new Set(current.map(image => `${image.name}-${image.size}`));
        return [...current,...uploaded.filter(image => {const key=`${image.name}-${image.size}`; if(existing.has(key)){URL.revokeObjectURL(image.previewUrl);return false;}existing.add(key);return true;})];
      });
      setCsvError(undefined);
    } catch { setCsvError("Image could not be read. Please select it again."); }
  };

  const handleCsvSelected = (file: File | null) => {
    if (!file) return;
    const revision = ++csvReadRevision.current;
    if (!/\.csv$/i.test(file.name) || file.size > MAX_CSV_BYTES || file.size <= 0) { setCsvError("Use a CSV file up to 2 MB."); return; }
    const epoch = operationEpoch.current;
    file.text().then((text) => {
      if (epoch !== operationEpoch.current || revision !== csvReadRevision.current) return;
      const parsed = parseCsv(file.name, text);
      setCsvError(undefined);
      setCsvFiles([{ id: `${file.name}-${file.lastModified}-${file.size}`, fileName: file.name, size: file.size, uploadedAt: new Date().toISOString(), parsed }]);
    }).catch((error) => {
      if (epoch !== operationEpoch.current || revision !== csvReadRevision.current) return;
      const message = error instanceof Error ? error.message : "CSV could not be parsed.";
      setCsvError(message);

    });
  };

  const removeImage = (imageId: string) => {
    setImages((current) => {
      const target = current.find((image) => image.id === imageId);
      if (target) URL.revokeObjectURL(target.previewUrl);
      return current.filter((image) => image.id !== imageId);
    });
  };

  const removeCsv = (fileId: string) => {
    setCsvFiles((current) => current.filter((file) => file.id !== fileId));
    setCsvError(undefined);
  };

  const clearSession = () => {
    operationEpoch.current += 1;
    clearWorkspaceData();
    images.forEach(image => URL.revokeObjectURL(image.previewUrl));
    imageUrls.current.clear();
    setImages([]); setCsvFiles([]); setProducts([]); setSelectedProductId(undefined);
    setCsvError(undefined); setDraftOpen(false); setFilter("all"); setUpdatedProductId(undefined);
  };

  const analyzeSelected = () => {
    if (!selectedProductId) return;
    const productId = selectedProductId;
    const epoch = operationEpoch.current;
    setProducts((current) => current.map((product) => product.id === productId ? { ...product, analysisState: "analyzing", error: undefined } : product));
    window.setTimeout(() => {
      if (epoch !== operationEpoch.current) return;
      setProducts((current) => current.map((product) => withDraft({ ...product, analysisState: "analyzed" })));
      setDraftOpen(false);
    }, 450);
  };

  const originalSourceFor = (source?: EvidenceSource): InventorySourceCell | undefined => {
    if (!source?.fileName || !source.rowNumber || !source.columnName || !source.cell) return source?.originalSource;
    return { file: source.fileName, row: source.rowNumber, column: source.columnName, cell: source.cell, value: source.value ?? source.snippet };
  };

  const sellerSource = (productId: string, key: ProductFieldKey, value: string, previous?: EvidenceSource): EvidenceSource => ({
    id: `seller:${productId}:${key}:${Date.now()}:${++sourceSequence.current}`,
    type: "seller_confirmation",
    label: "Seller edit",
    confidence: 0,
    snippet: value,
    value,
    createdAt: new Date().toISOString(),
    location: "Seller review form",
    originalSource: originalSourceFor(previous),
    reason: "Seller correction or confirmation"
  });

  const updateField = (key: ProductFieldKey, value: string, forcedStatus?: "seller_confirmed" | "needs_confirmation" | "rejected") => {
    if (!selectedProductId || key === "productId") return;
    if (["donorYear","donorYearFromNotes","weightKg","dimensionsCm","askingPrice"].includes(key)) value = value.replace(/[٠-٩]/g,c => String(c.charCodeAt(0)-1632)).replace(/[۰-۹]/g,c => String(c.charCodeAt(0)-1776)).replace(/٫/g,".");
    updateProduct(selectedProductId, (product) => {
      const previous = product.fields[key];
      const original = previous.history.find((source) => source.type !== "seller_confirmation") ?? previous.sources[0];
      const source = sellerSource(product.id, key, value || previous.value || "Marked by seller", original);
      const nextField = {
        ...previous,
        value,
        reviewDecision: forcedStatus === "needs_confirmation" ? "needs_review" as const : forcedStatus === "rejected" ? "rejected" as const : "confirmed" as const,
        reviewedValue: value,
        reviewContext: reviewContextFor({...product.fields,[key]:{...previous,value}},key),
        status: forcedStatus ?? (value ? "seller_confirmed" as const : "missing" as const),
        sources: forcedStatus === "needs_confirmation" || forcedStatus === "rejected" ? previous.sources : [source],
        history: [...previous.history, source],
        issue: forcedStatus === "needs_confirmation" ? "Seller marked this field for review." : forcedStatus === "rejected" ? "Seller rejected this value." : undefined
      };
      return withDraft({ ...product, approvalStatus: "not_reviewed", fields: { ...product.fields, [key]: nextField } });
    });
  };

  const confirmField = (key: ProductFieldKey) => {
    const value = selectedProduct?.fields[key].value ?? "";
    if (value) updateField(key, value, "seller_confirmed");
  };

  const updateDraft = (draft: EditableListingDraft) => {
    if (!selectedProductId) return;
    updateProduct(selectedProductId, (product) => ({ ...product, draft, approvalStatus: "not_reviewed" }));
  };

  const approveDraft = () => {
    if (!selectedProductId) return;
    updateProduct(selectedProductId, (product) => ({ ...product, approvalStatus: "seller_approved" }));
  };

  return (
    <LocaleProvider language={language}><div dir={directionFor(language)} className="min-h-screen bg-[#F7F9FC] text-[#172B4D]">
      <AppHeader language={language} onToggleLanguage={() => setLanguage((current) => current === "en" ? "ar" : "en")} onRestart={() => { try { clearWorkspaceData(); } catch {} setProducts(buildProductsFromUploads(csvFiles, images)); setDraftOpen(false); setFilter("all"); }} onAddFiles={() => uploadRef.current?.scrollIntoView({ behavior: "smooth", block: "start" })} />
      <main className="mx-auto max-w-7xl px-4 pb-10 pt-36 sm:pt-28 sm:px-6">
        <section className="mb-6">
          <h1 className="text-3xl font-bold tracking-tight text-[#172B4D]">{t.heading}</h1>
          <p className="mt-2 text-lg text-slate-600">{t.subheading}</p>
        </section>

        <PrivacyPanel onClear={clearSession} />
        <SummaryCards summary={summary} activeFilter={filter} onFilter={setFilter} />

        <div ref={uploadRef} className="mt-5 space-y-5">
          <UploadWorkspace images={images} csvFiles={csvFiles} products={products} csvError={csvError} onImagesSelected={handleImagesSelected} onCsvSelected={handleCsvSelected} onRemoveImage={removeImage} onRemoveCsv={removeCsv} />
          <ProductSelector products={filteredProducts} images={images} selectedId={selectedProductId} onSelect={(id) => { setSelectedProductId(id); setDraftOpen(false); }} />
          <ManualAssociationPanel images={images} products={products} onAssociate={(imageId, productId) => setImages((current) => applyManualAssociation(current, imageId, productId))} />
          {!products.length && <p className="rounded-xl border border-slate-200 bg-white p-5 text-sm text-slate-600 shadow-sm">{t.empty}</p>}
          <p className="text-sm text-slate-500">{t.noVision}</p>
          <ReviewWorkspace
            product={selectedProduct}
            images={images}
            draftOpen={draftOpen}
            updated={updatedProductId === selectedProductId}
            onAnalyze={analyzeSelected}
            onViewDraft={() => setDraftOpen((value) => !value)}
            onFieldChange={(key, value) => updateField(key, value)}
            onConfirm={confirmField}
            onNeedsReview={(key) => updateField(key, selectedProduct?.fields[key].value ?? "", "needs_confirmation")}
            onReject={(key) => updateField(key, selectedProduct?.fields[key].value ?? "", "rejected")}
            onDraftChange={updateDraft}
            onApproveDraft={approveDraft}
          />
        </div>
      </main>
    </div></LocaleProvider>
  );
}

export default App;
