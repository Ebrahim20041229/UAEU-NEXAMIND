import type { Language, ReadinessStatus } from "../types/salvage";

export const directionFor = (language: Language) => language === "ar" ? "rtl" : "ltr";

export const copy = {
  en: {
    addFiles: "Add files",
    language: "العربية",
    heading: "Prepare your next eBay listing.",
    subheading: "Upload photos. Confirm details. Review your draft.",
    uploadTitle: "Upload product files",
    uploadHelp: "CSV is recommended. Images can be added now and matched by product ID plus explicit image filename columns.",
    selectProduct: "Select product",
    analyze: "Analyze product",
    viewDraft: "View listing draft",
    empty: "Upload images, a CSV, or both to start. Analysis runs only after you select a product and click Analyze.",
    noVision: "Image content is attached as evidence but not automatically analyzed in this prototype.",
    moreDetails: "More details",
    updated: "Updated",
    draftApproval: "Seller approval required"
  },
  ar: {
    addFiles: "إضافة ملفات",
    language: "English",
    heading: "جهّز إعلانك القادم على eBay.",
    subheading: "ارفع الصور، راجع البيانات، وجهّز مسودة الإعلان.",
    uploadTitle: "ارفع ملفات القطعة",
    uploadHelp: "CSV هو التنسيق الأساسي. يمكن رفع الصور الآن وربطها عبر product ID وأسماء الصور في الملف.",
    selectProduct: "اختر المنتج",
    analyze: "حلّل المنتج",
    viewDraft: "عرض مسودة الإعلان",
    empty: "ارفع صوراً أو CSV أو الاثنين. التحليل يبدأ فقط بعد اختيار منتج والضغط على تحليل.",
    noVision: "الصور مرفقة كدليل، لكن محتواها لا يُحلل آلياً في هذا النموذج.",
    moreDetails: "تفاصيل إضافية",
    updated: "تم التحديث",
    draftApproval: "موافقة البائع مطلوبة"
  }
};

export const readinessLabels: Record<Language, Record<ReadinessStatus, string>> = {
  en: {
    ready_for_review: "Ready for review",
    information_missing: "Missing information",
    specialist_review_required: "Specialist review"
  },
  ar: {
    ready_for_review: "جاهز للمراجعة",
    information_missing: "معلومات ناقصة",
    specialist_review_required: "مراجعة مختص"
  }
};
