import {createContext, useContext, type ReactNode} from "react";
import type {Language} from "../types/salvage";
import ar from "./ar.json";
const Context=createContext<Language>("en");
export function LocaleProvider({language,children}:{language:Language;children:ReactNode}) {return <Context.Provider value={language}>{children}</Context.Provider>}
export function translate(text:string|undefined,language:Language):string {
 if (!text) return "";
 if(language!=="ar") return text;
 const entries=ar as Record<string,string>;
 if(entries[text.trim()])return entries[text.trim()];
 const patterns:[RegExp,(m:RegExpMatchArray)=>string][]=[
 [/^(.*) · row (\d+) · (.*)$/,m=>`${m[1]} · الصف ${m[2]} · ${m[3]}`],
 [/^CSV donor year (.*?) conflicts with note year (.*?)\.$/,m=>`سنة السيارة ${m[1]} تختلف عن سنة الملاحظات ${m[2]}. حدّد السنة الصحيحة.`],
 [/^(Total asking value|Ready value|Next action) (.*)$/,m=>`${({"Total asking value":"إجمالي الأسعار المطلوبة","Ready value":"قيمة القطع الجاهزة","Next action":"الخطوة التالية"} as Record<string,string>)[m[1]]}: ${m[2]}`],
 [/^(.*?)?: (.*)$/,m=>entries[m[1]]?`${entries[m[1]]}: ${translate(m[2],language)}`:text],
 [/^matched to (.*)$/,m=>`مرتبطة بالقطعة ${m[1]}`],
 [/^Missing CSV columns: (.*)\.$/,m=>`أعمدة ناقصة في ملف البيانات: ${m[1]}`],
 [/^Duplicate product_id: (.*)\.$/,m=>`رقم قطعة مكرر: ${m[1]}`],
 [/^Missing product_id in CSV row (.*)\.$/,m=>`رقم القطعة غير موجود في الصف ${m[1]}`],
 [/^Incorrect cell count in CSV row (.*): found (.*), expected (.*)\.$/,m=>`عدد الخلايا غير صحيح في الصف ${m[1]}: الموجود ${m[2]} والمطلوب ${m[3]}`],
 [/^Remove (.*)$/,m=>`حذف ${m[1]}`],
 [/^Associate (.*) to product$/,m=>`ربط ${m[1]} بالقطعة`],
 ];
 for(const [pattern,format] of patterns){const match=text.match(pattern);if(match){const result=format(match);if(result!==text)return result;}}
 return text;
}
export function useT(){const language=useContext(Context);return (text:string|undefined)=>translate(text,language);}
