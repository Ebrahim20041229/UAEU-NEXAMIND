export type EvidenceStatus =
  | "supported"
  | "seller_confirmed"
  | "needs_confirmation"
  | "missing"
  | "invalid"
  | "conflict"
  | "unverified"
  | "rejected";

export type ReadinessStatus = "ready_for_review" | "information_missing" | "specialist_review_required";

export type SourceType = "photo" | "spreadsheet" | "donor_note" | "arabic_note" | "seller_confirmation" | "reference_db";

export interface InventorySourceCell {
  file: string;
  row: number;
  column: string;
  cell: string;
  value: string;
}

export interface EvidenceSource {
  id: string;
  type: SourceType;
  label: string;
  confidence: number;
  snippet: string;
  fileName?: string;
  rowNumber?: number;
  columnName?: string;
  cell?: string;
  location?: string;
  value?: string;
  createdAt?: string;
  originalSource?: InventorySourceCell;
  reason?: string;
}

export interface PartAttribute {
  field: string;
  label: string;
  value?: string;
  status: EvidenceStatus;
  sources: EvidenceSource[];
}

export interface CompatibilityRecord {
  partNumber: string;
  supportedVehicles: string[];
  sourceId: string;
}

export interface PartRecord {
  id: string;
  title: string;
  family: string;
  image: string;
  price: string;
  location: string;
  confidenceScore: number;
  attributes: PartAttribute[];
  attemptedUnsafeClaim?: string;
}

export interface Conflict {
  field: string;
  label: string;
  values: { value: string; source: EvidenceSource }[];
  question: string;
}

export interface ListingClaim {
  text: string;
  claimType: "compatibility" | "condition" | "functionality" | "identifier" | "shipping";
  status: "supported" | "unverified" | "removed" | "requires_confirmation";
  reason: string;
  sourceIds: string[];
}

export interface ListingDraft {
  title: string;
  category: string;
  description: string;
  itemSpecifics: { label: string; value: string; status: EvidenceStatus }[];
  claims: ListingClaim[];
}

export interface ReadinessResult {
  status: ReadinessStatus;
  score: number;
  actions: string[];
  blockers: string[];
}

export interface UploadedImage {
  id: string;
  name: string;
  type: string;
  size: number;
  previewUrl: string;
  productId?: string;
  matchStatus?: "matched" | "manual" | "unmatched" | "ambiguous";
}

export interface UploadedCsvFile {
  id: string;
  fileName: string;
  size: number;
  uploadedAt: string;
  parsed: ParsedCsv;
}

export interface CsvRowMeta {
  rowNumber: number;
  widthMismatch?: boolean;
  extraValues?: string[];
}

export interface ParsedCsv {
  fileName: string;
  headers: string[];
  rows: Record<string, string>[];
  rowMeta?: CsvRowMeta[];
  warnings?: string[];
}

export interface EvidenceFormState {
  partType: string;
  manufacturer: string;
  partNumber: string;
  donorVehicle: string;
  donorYear: string;
  position: string;
  condition: string;
  testingStatus: string;
  weight: string;
  dimensions: string;
  price: string;
  location: string;
}

export type ProductFieldKey =
  | "productId"
  | "imageFilename"
  | "partType"
  | "manufacturer"
  | "partNumber"
  | "donorVehicle"
  | "donorYear"
  | "position"
  | "condition"
  | "defects"
  | "testingStatus"
  | "includedComponents"
  | "weightKg"
  | "dimensionsCm"
  | "askingPrice"
  | "currency"
  | "storageLocation"
  | "notes"
  | "donorYearFromNotes"
  | "partNumberLegibility"
  | "compatibilityReference";

export interface EvidenceField {
  reviewDecision?: "confirmed" | "needs_review" | "rejected";
  reviewedValue?: string;
  reviewContext?: string;
  key: ProductFieldKey;
  label: string;
  value?: string;
  status: EvidenceStatus;
  confidence?: number;
  confidenceExplanation: string;
  issue?: string;
  code?: string;
  blocking?: boolean;
  sources: EvidenceSource[];
  relatedSources?: EvidenceSource[];
  history: EvidenceSource[];
}

export interface EditableListingDraft {
  manuallyEdited?: boolean;
  title: string;
  description: string;
  category: string;
  itemSpecifics: { label: string; value: string; status: EvidenceStatus }[];
  conditionDisclosure: string;
  testingDisclosure: string;
  compatibilityDisclosure: string;
  exportedAt?: string;
}

export interface ProductWorkspaceRecord {
  id: string;
  displayName: string;
  family: string;
  rowOrder: number;
  csvRowId?: string;
  csvFileName?: string;
  imageIds: string[];
  associatedFilenames: string[];
  unmatchedFilenames: string[];
  matchIssue?: string;
  validationColor: "green" | "amber" | "red";
  checksPassedPercent: number;
  confidencePercent: number | null;
  imageAnalysisPerformed: boolean;
  fields: Record<ProductFieldKey, EvidenceField>;
  analysisState: "not_analyzed" | "analyzing" | "analyzed" | "error";
  readinessStatus: ReadinessStatus;
  readinessScore: number;
  draft?: EditableListingDraft;
  approvalStatus: "not_reviewed" | "seller_approved";
  updatedAt?: string;
  error?: string;
}

export interface WorkspaceSummary {
  total: number;
  missing: number;
  specialist: number;
  ready: number;
  green: number;
  amber: number;
  red: number;
  inventoryValueByCurrency: Record<string, number>;
  readyValueByCurrency: Record<string, number>;
  nextProductId: string | null;
}

export type Language = "en" | "ar";

export type StatusFilter = "all" | ReadinessStatus;
