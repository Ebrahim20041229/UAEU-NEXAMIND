import type { CompatibilityRecord } from "../types/salvage";

export const compatibilityReference: CompatibilityRecord[] = [
  {
    partNumber: "87940-02A10",
    supportedVehicles: ["Toyota Corolla 2018 GCC Sedan Left Mirror"],
    sourceId: "ref-ebay-fitment-uae-uk-v1"
  },
  {
    partNumber: "87910-02B30",
    supportedVehicles: ["Toyota Corolla 2018 GCC Sedan Right Mirror"],
    sourceId: "ref-ebay-fitment-uae-uk-v1"
  },
  {
    partNumber: "76250-TBA-A01",
    supportedVehicles: ["Honda Civic 2017 Sedan Left Mirror"],
    sourceId: "ref-ebay-fitment-uae-uk-v1"
  },
  {
    partNumber: "96302-5AA0A",
    supportedVehicles: ["Nissan Altima 2016 Left Mirror"],
    sourceId: "ref-ebay-fitment-uae-uk-v1"
  }
];
