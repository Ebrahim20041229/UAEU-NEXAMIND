export const requiredListingFields = [
  "part_type",
  "manufacturer",
  "part_number",
  "donor_vehicle",
  "donor_year",
  "position",
  "condition",
  "testing_status"
];

export const requiredShippingFields = ["weight", "dimensions"];

export const readinessCopy = {
  ready_for_review: "Ready for seller review",
  information_missing: "Information missing",
  specialist_review_required: "Specialist review required"
};

export const checklistMetadata = {
  corridor: "UAE → UK",
  source: "SalvageTrust prototype listing/shipping checklist",
  version: "2026.10-demo",
  date: "2026-10-27",
  note: "Prototype readiness checklist only; not customs, legal, or shipping clearance."
};
