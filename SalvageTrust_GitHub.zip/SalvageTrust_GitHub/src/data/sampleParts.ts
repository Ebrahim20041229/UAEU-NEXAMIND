import type { EvidenceSource, PartRecord } from "../types/salvage";

const source = (id: string, type: EvidenceSource["type"], label: string, confidence: number, snippet: string): EvidenceSource => ({
  id,
  type,
  label,
  confidence,
  snippet
});

const photo = (part: string, n: number, snippet: string, confidence = 0.84) =>
  source(`${part}-photo-${n}`, "photo", `Photo ${n}`, confidence, snippet);
const sheet = (part: string, snippet: string, confidence = 0.9) =>
  source(`${part}-spreadsheet`, "spreadsheet", "Inventory spreadsheet", confidence, snippet);
const donor = (part: string, snippet: string, confidence = 0.88) =>
  source(`${part}-donor-note`, "donor_note", "Dismantling note", confidence, snippet);
const arabic = (part: string, snippet: string, confidence = 0.82) =>
  source(`${part}-arabic-note`, "arabic_note", "Arabic yard note", confidence, snippet);

export const sampleParts: PartRecord[] = [
  {
    id: "MIR-001",
    title: "Toyota Corolla Left Side Mirror — difficult case",
    family: "Side-view mirrors",
    image: "https://placehold.co/560x360/111827/38BDF8?text=Corolla+Mirror+Photos",
    price: "$45",
    location: "Rack B-12, Dubai yard",
    confidenceScore: 61,
    attemptedUnsafeClaim: "Fits Toyota Corolla 2015-2019 with power folding mirror.",
    attributes: [
      { field: "part_type", label: "Part type", value: "Side-view mirror", status: "supported", sources: [photo("MIR-001", 1, "Mirror housing visible from front and rear", 0.91)] },
      { field: "manufacturer", label: "Manufacturer", value: "Toyota", status: "supported", sources: [sheet("MIR-001", "Toyota Corolla mirror, left", 0.88)] },
      { field: "part_number", label: "Part number", value: "87940-02A??", status: "needs_confirmation", sources: [photo("MIR-001", 2, "Label partially unreadable: 87940-02A..", 0.43)] },
      { field: "donor_vehicle", label: "Donor vehicle", value: "Toyota Corolla", status: "supported", sources: [sheet("MIR-001", "Toyota Corolla mirror"), donor("MIR-001", "Removed from Corolla sedan") ] },
      { field: "donor_year", label: "Donor year", value: "2017 / 2018", status: "conflict", sources: [sheet("MIR-001", "2017 Toyota Corolla"), donor("MIR-001", "2018 donor vehicle") ] },
      { field: "position", label: "Position", value: "Left", status: "supported", sources: [arabic("MIR-001", "مرآة يسار، مجربة، ممتازة", 0.81)] },
      { field: "condition", label: "Condition", value: "Possible cracked mounting tab", status: "needs_confirmation", sources: [photo("MIR-001", 3, "Potential crack on mounting tab", 0.72), arabic("MIR-001", "ممتازة", 0.78)] },
      { field: "testing_status", label: "Testing status", value: undefined, status: "missing", sources: [] },
      { field: "weight", label: "Weight", value: undefined, status: "missing", sources: [] },
      { field: "dimensions", label: "Dimensions", value: "34 x 22 x 18 cm", status: "supported", sources: [sheet("MIR-001", "Dimensions measured in packing area", 0.86)] }
    ]
  },
  ...[
    ["MIR-002", "Toyota Corolla Right Side Mirror", "Toyota", "87910-02B30", "Toyota Corolla", "2018", "Right", "Tested working, light scuffs", "$49", 92],
    ["MIR-003", "Honda Civic Left Side Mirror", "Honda", "76250-TBA-A01", "Honda Civic", "2017", "Left", "Tested working, clean glass", "$55", 95],
    ["MIR-004", "Nissan Altima Left Side Mirror", "Nissan", "96302-5AA0A", "Nissan Altima", "2016", "Left", "Used, minor scratches", "$42", 88],
    ["MIR-005", "Toyota Corolla Left Mirror — missing weight", "Toyota", "87940-02A10", "Toyota Corolla", "2018", "Left", "Tested working", "$44", 84],
    ["MIR-006", "Kia Rio Right Mirror — missing part number", "Kia", "", "Kia Rio", "2019", "Right", "Untested, cosmetic wear", "$38", 58],
    ["MIR-007", "Hyundai Elantra Left Mirror", "Hyundai", "87610-F2AA0", "Hyundai Elantra", "2017", "Left", "Tested, paint scratches", "$47", 81],
    ["MIR-008", "Mazda 3 Right Mirror", "Mazda", "B63B-69-120", "Mazda 3", "2016", "Right", "Glass intact, untested folding motor", "$41", 74],
    ["MIR-009", "Ford Focus Left Mirror", "Ford", "F1EZ-17683-A", "Ford Focus", "2015", "Left", "Cracked cover included in disclosure", "$36", 79],
    ["MIR-010", "Chevrolet Cruze Right Mirror", "Chevrolet", "94563472", "Chevrolet Cruze", "2017", "Right", "Tested working", "$40", 87]
  ].map(([id, title, manufacturer, partNumber, vehicle, year, position, condition, price, score]) => {
    const partId = String(id);
    const conditionText = String(condition);
    const isUntested = conditionText.toLowerCase().includes("untested");
    const isTested = conditionText.toLowerCase().includes("tested") || conditionText.toLowerCase().includes("working");

    return {
      id: partId,
      title: String(title),
      family: "Side-view mirrors",
      image: `https://placehold.co/560x360/0F172A/38BDF8?text=${partId}+Mirror`,
      price: String(price),
      location: `Rack ${partId.slice(-2)} Dubai yard`,
      confidenceScore: Number(score),
      attemptedUnsafeClaim: `Fits a broad range of ${vehicle} model years.`,
      attributes: [
        { field: "part_type", label: "Part type", value: "Side-view mirror", status: "supported", sources: [photo(partId, 1, "Mirror part identified from uploaded photos")] },
        { field: "manufacturer", label: "Manufacturer", value: String(manufacturer), status: "supported", sources: [sheet(partId, `${manufacturer} mirror record`)] },
        { field: "part_number", label: "Part number", value: String(partNumber) || undefined, status: partNumber ? "supported" : "missing", sources: partNumber ? [photo(partId, 2, `Readable label: ${partNumber}`, 0.86)] : [] },
        { field: "donor_vehicle", label: "Donor vehicle", value: String(vehicle), status: "supported", sources: [donor(partId, `Removed from ${vehicle}`)] },
        { field: "donor_year", label: "Donor year", value: String(year), status: "supported", sources: [donor(partId, `${year} donor vehicle`)] },
        { field: "position", label: "Position", value: String(position), status: "supported", sources: [sheet(partId, `${position} side mirror`)] },
        { field: "condition", label: "Condition", value: conditionText, status: isUntested ? "needs_confirmation" : "supported", sources: [photo(partId, 3, conditionText, 0.79)] },
        { field: "testing_status", label: "Testing status", value: isTested ? "Recorded" : "Not recorded", status: isUntested ? "needs_confirmation" : "supported", sources: [sheet(partId, isTested ? "Testing noted by yard" : "No electrical test recorded", 0.72)] },
        { field: "weight", label: "Weight", value: partId === "MIR-005" ? undefined : "1.4 kg", status: partId === "MIR-005" ? "missing" : "supported", sources: partId === "MIR-005" ? [] : [sheet(partId, "Packing scale entry: 1.4 kg", 0.82)] },
        { field: "dimensions", label: "Dimensions", value: "34 x 22 x 18 cm", status: "supported", sources: [sheet(partId, "Packing dimensions recorded", 0.84)] }
      ]
    };
  }) as PartRecord[]
];
