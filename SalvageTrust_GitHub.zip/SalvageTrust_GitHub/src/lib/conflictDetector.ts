import type { Conflict, PartAttribute, PartRecord } from "../types/salvage";

const splitConflictValue = (value?: string) =>
  value?.includes("/") ? value.split("/").map((item) => item.trim()).filter(Boolean) : [];

export const detectConflicts = (part: PartRecord): Conflict[] => {
  return part.attributes
    .filter((attribute) => attribute.status === "conflict" || splitConflictValue(attribute.value).length > 1)
    .map((attribute) => ({
      field: attribute.field,
      label: attribute.label,
      values: buildConflictValues(attribute),
      question: `Confirm the correct ${attribute.label.toLowerCase()} before the listing can be trusted.`
    }));
};

const buildConflictValues = (attribute: PartAttribute) => {
  const explicitValues = splitConflictValue(attribute.value);
  if (explicitValues.length > 1) {
    return explicitValues.map((value, index) => ({
      value,
      source: attribute.sources[index] ?? attribute.sources[0]
    }));
  }

  return attribute.sources.map((source, index) => ({
    value: index === 0 ? attribute.value ?? "Unknown" : source.snippet.match(/20\d{2}/)?.[0] ?? source.snippet,
    source
  }));
};
