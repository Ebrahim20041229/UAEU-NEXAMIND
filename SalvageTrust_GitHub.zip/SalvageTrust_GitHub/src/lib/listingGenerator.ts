import type { CompatibilityRecord, EditableListingDraft, EvidenceField, ListingClaim, ListingDraft, PartRecord, ProductWorkspaceRecord } from "../types/salvage";
import { getSupportedCompatibility, reviewClaims } from "./fitGuard";
import { getAttribute } from "./trustEngine";

const safeStatuses = new Set(["supported", "seller_confirmed"]);
const clean = (value?: string) => (value ?? "").trim();
const usable = (field?: EvidenceField) => field && clean(field.value) && safeStatuses.has(field.status) ? clean(field.value) : "";
const partValue = (part: PartRecord, field: string) => clean(getAttribute(part, field)?.value);
const noPlaceholder = (value: string) => !/(requires seller confirmation|not captured|null|undefined|unknown unknown|not provided)/i.test(value);

const compactTitle = (pieces: string[]) => {
  const unique = pieces.filter(Boolean).filter(noPlaceholder).filter((piece, index, array) => array.findIndex((item) => item.toLowerCase() === piece.toLowerCase()) === index);
  return unique.length ? unique.join(" ").replace(/\s+/g, " ").trim() : "Used automotive part for seller review";
};

const safeValue = (field: EvidenceField, fallback = "Not provided") => usable(field) || fallback;

export const generateWorkspaceDraft = (product: ProductWorkspaceRecord, reference: CompatibilityRecord[]): EditableListingDraft => {
  const fields = product.fields;
  const partNumber = usable(fields.partNumber);
  const compatibility = undefined as CompatibilityRecord | undefined; // Demo mirror references must not certify uploaded vents.
  const title = compactTitle([usable(fields.manufacturer), usable(fields.partType), usable(fields.donorVehicle)]);
  const defects = clean(fields.defects.value);
  const condition = clean(fields.condition.value);
  const testing = usable(fields.testingStatus);
  const components = usable(fields.includedComponents);
  const donor = [usable(fields.donorYear), usable(fields.donorVehicle)].filter(Boolean).join(" ");

  const conditionDisclosure = ["rejected","conflict","missing"].includes(fields.condition.status)
    ? `Condition requires seller review.${defects ? ` Recorded defect note: ${defects}` : ""}`
    : defects
    ? `${condition === "for_parts" ? "For parts or repair only" : "Used condition"}. Known defects: ${defects}`
    : condition
      ? `Condition recorded as ${condition}. No extra defect note was supplied.`
      : "Condition details are incomplete.";

  const testingDisclosure = testing === "tested_working"
    ? "Seller recorded testing status: tested_working. Do not treat the photo alone as proof of operation."
    : testing === "untested"
      ? "Untested; operation is not confirmed."
      : testing === "not_recorded"
        ? "Testing status has not been recorded."
        : "Testing status is not available.";

  const compatibilityDisclosure = compatibility
    ? `Compatibility supported only by exact reference: ${compatibility.supportedVehicles.join(", ")}.`
    : "Vehicle compatibility is unverified. Match the part number, shape, mounts and connector before purchase.";

  const description = [
    `${title}.`,
    components ? `Included: ${components}.` : "Included components are not fully documented.",
    donor ? `Donor record: ${donor}. This does not prove fitment.` : "Donor vehicle details are incomplete.",
    conditionDisclosure,
    testingDisclosure,
    compatibilityDisclosure,
    "Final listing approval remains with the seller."
  ].join(" ");

  return {
    title,
    description,
    category: /vent/i.test(fields.partType.value ?? "")
      ? "eBay Motors > Parts & Accessories > Interior Parts & Accessories > Dash Parts"
      : "eBay Motors > Parts & Accessories",
    itemSpecifics: [
      { label: "Product ID", value: product.id, status: fields.productId.status },
      { label: "Part type", value: safeValue(fields.partType), status: fields.partType.status },
      { label: "Manufacturer", value: safeValue(fields.manufacturer), status: fields.manufacturer.status },
      { label: "Part number", value: safeValue(fields.partNumber), status: fields.partNumber.status },
      { label: "Position", value: safeValue(fields.position), status: fields.position.status },
      { label: "Donor vehicle", value: safeValue(fields.donorVehicle), status: fields.donorVehicle.status },
      { label: "Donor year", value: safeValue(fields.donorYear), status: fields.donorYear.status },
      { label: "Net item/lot weight", value: safeValue(fields.weightKg), status: fields.weightKg.status },
      { label: "Dimensions", value: safeValue(fields.dimensionsCm), status: fields.dimensionsCm.status },
      { label: "Asking price", value: `${safeValue(fields.askingPrice)} ${clean(fields.currency.value)}`.trim(), status: fields.askingPrice.status }
    ],
    conditionDisclosure,
    testingDisclosure,
    compatibilityDisclosure
  };
};

export const generateListingDraft = (part: PartRecord, reference: CompatibilityRecord[]): ListingDraft => {
  const supportedCompatibility = getSupportedCompatibility(part, reference);
  const donorYear = partValue(part, "donor_year");
  const donorVehicle = partValue(part, "donor_vehicle");
  const condition = partValue(part, "condition");
  const testing = partValue(part, "testing_status");
  const baseClaims: ListingClaim[] = [
    {
      text: donorYear || donorVehicle ? `Donor vehicle: ${[donorYear, donorVehicle].filter(Boolean).join(" ")}.` : "Donor vehicle not documented.",
      claimType: "identifier",
      status: getAttribute(part, "donor_year")?.status === "conflict" ? "requires_confirmation" : donorVehicle ? "supported" : "unverified",
      reason: "Donor vehicle information is shown separately from compatibility claims.",
      sourceIds: getAttribute(part, "donor_vehicle")?.sources.map((source) => source.id) ?? []
    },
    {
      text: supportedCompatibility.length ? `Verified compatibility: ${supportedCompatibility.join(", ")}.` : "Broader compatibility not verified.",
      claimType: "compatibility",
      status: supportedCompatibility.length ? "supported" : "unverified",
      reason: supportedCompatibility.length ? "Matched approved reference dataset." : "No exact reference match; donor vehicle alone does not prove fitment.",
      sourceIds: supportedCompatibility.length ? ["ref-ebay-fitment-uae-uk-v1"] : []
    },
    {
      text: condition ? `Condition disclosure: ${condition}.` : "Condition details missing.",
      claimType: "condition",
      status: condition ? "supported" : "requires_confirmation",
      reason: "Condition is based on seller-provided notes and attached photo evidence, without automated damage detection.",
      sourceIds: getAttribute(part, "condition")?.sources.map((source) => source.id) ?? []
    },
    {
      text: testing ? `Testing status: ${testing}.` : "Testing not recorded.",
      claimType: "functionality",
      status: getAttribute(part, "testing_status")?.status === "supported" ? "supported" : "requires_confirmation",
      reason: "Functionality requires explicit test evidence.",
      sourceIds: getAttribute(part, "testing_status")?.sources.map((source) => source.id) ?? []
    }
  ];

  const claims = reviewClaims(part, reference, baseClaims);
  const title = compactTitle([partValue(part, "manufacturer"), partValue(part, "position"), partValue(part, "part_type"), partValue(part, "donor_vehicle")]);

  return {
    title,
    category: /mirror/i.test(partValue(part, "part_type")) ? "eBay Motors > Parts & Accessories > Exterior Parts & Accessories > Side View Mirrors" : "eBay Motors > Parts & Accessories",
    description: `Used part prepared for seller review. ${condition ? `Condition: ${condition}.` : "Condition details are incomplete."} ${supportedCompatibility.length ? `Compatibility: ${supportedCompatibility.join(", ")}.` : "Broader compatibility is not verified."}`,
    itemSpecifics: [
      { label: "Part Type", value: partValue(part, "part_type") || "Not provided", status: getAttribute(part, "part_type")?.status ?? "missing" },
      { label: "Manufacturer", value: partValue(part, "manufacturer") || "Not provided", status: getAttribute(part, "manufacturer")?.status ?? "missing" },
      { label: "Part Number", value: partValue(part, "part_number") || "Not provided", status: getAttribute(part, "part_number")?.status ?? "missing" },
      { label: "Position", value: partValue(part, "position") || "Not provided", status: getAttribute(part, "position")?.status ?? "missing" },
      { label: "Condition", value: condition || "Not provided", status: getAttribute(part, "condition")?.status ?? "missing" }
    ],
    claims
  };
};
