import type { EvidenceField, EvidenceSource } from "../types/salvage";

export interface SourcePointer { file?: string; row?: number; column?: string; cell?: string }
export const pointerFor = (source?: EvidenceSource): SourcePointer => source?.originalSource
  ? {file:source.originalSource.file,row:source.originalSource.row,column:source.originalSource.column,cell:source.originalSource.cell}
  : {file:source?.fileName,row:source?.rowNumber,column:source?.columnName,cell:source?.cell};

/** A display projection only: source text, values and history are never changed. */
export const buildEvidencePreview = (field: EvidenceField) => {
  const active = field.sources[0];
  const pointer = pointerFor(active);
  const seen = new Set<string>();
  const details = [...field.sources,...(field.relatedSources ?? []),...field.history].filter(source => {
    const key = source.type === "seller_confirmation" ? `edit:${source.id}` : JSON.stringify([source.type,source.fileName,source.rowNumber,source.columnName,source.cell,source.value ?? source.snippet]);
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
  const alternatives = field.status === "conflict" ? details.filter(source => {
    const other = pointerFor(source);
    const value = source.value ?? source.snippet;
    return source.type !== "seller_confirmation" && !!other.cell && other.column !== "notes" && value.trim() !== "" && value.length <= 80
      && !(other.file === pointer.file && other.cell === pointer.cell);
  }) : [];
  return {label:active?.type === "seller_confirmation" ? "Seller edit" : active?.label ?? "No supporting evidence.", pointer, value:field.value ?? "", alternatives, details};
};

const briefMessages: Record<string,string> = {
  missing_value:"Add this information.", image_not_uploaded:"Upload the matching image.",
  invalid_year:"Enter a valid vehicle year.", year_conflict:"Years do not match. Choose the correct year.",
  identifier_needs_confirmation:"Confirm the part number.", legibility_not_recorded:"Check the part-number label.",
  position_needs_confirmation:"Confirm the installation position.", invalid_position:"Choose a valid installation position.",
  specialist_review_required:"This part needs specialist review.", invalid_condition:"Choose the part condition.",
  testing_not_recorded:"Confirm the testing status.", faulty_disclosure_required:"Disclose that the part is faulty.",
  condition_test_conflict:"Condition and test results do not match.", invalid_testing_status:"Choose a valid testing status.",
  invalid_net_weight:"Enter a net weight above zero.", invalid_dimensions:"Enter three valid dimensions.",
  price_not_recorded:"Add an asking price.", invalid_price:"Enter a valid asking price.", invalid_currency:"Choose a valid currency.",
  compatibility_unverified:"Vehicle compatibility is unverified.", reference_not_verified:"The compatibility reference needs checking.",
  seller_rejected:"Seller rejected this value.", seller_review:"Seller marked this field for review."
};
export const briefEvidenceIssue = (field: EvidenceField) => field.issue ? briefMessages[field.code ?? ""] ?? field.issue : undefined;

export const evidenceDisplayValue = (field: EvidenceField, translate: (value:string)=>string): string => {
  const raw = field.value || "Unknown";
  if (!["position","condition","testingStatus","partNumberLegibility"].includes(field.key)) return field.value || translate("Unknown");
  const translated = translate(raw);
  if (translated !== raw) return translated;
  const labels: Record<string,string> = {not_recorded:"Not recorded",tested_working:"Tested working",untested:"Untested",faulty:"Faulty",used:"Used",for_parts:"For parts or repair",left:"Left",right:"Right",center:"Center",rear:"Rear",left_right:"Left and right",set:"Set",unconfirmed:"Unconfirmed",clear:"Clear",unclear:"Unclear",missing:"Missing"};
  return labels[raw] ?? raw;
};
