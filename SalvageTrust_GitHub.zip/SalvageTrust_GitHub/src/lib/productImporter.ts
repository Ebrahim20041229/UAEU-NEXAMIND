import type { EvidenceField, EvidenceSource, InventorySourceCell, ParsedCsv, ProductFieldKey, ProductWorkspaceRecord, UploadedCsvFile, UploadedImage } from "../types/salvage";
import { INVENTORY_COLUMNS } from "./csvParser";
import { analyzeProduct, createEmptyField, fieldLabels } from "./productAnalysis";

const fieldColumns: Record<ProductFieldKey, string> = {
  productId: "product_id",
  imageFilename: "image_filename",
  partType: "part_type",
  manufacturer: "manufacturer",
  partNumber: "part_number",
  donorVehicle: "donor_vehicle",
  donorYear: "donor_year",
  position: "position",
  condition: "condition",
  defects: "defects",
  testingStatus: "testing_status",
  includedComponents: "included_components",
  weightKg: "weight_kg",
  dimensionsCm: "dimensions_cm",
  askingPrice: "asking_price",
  currency: "currency",
  storageLocation: "storage_location",
  notes: "notes",
  donorYearFromNotes: "donor_year_from_notes",
  partNumberLegibility: "part_number_legibility",
  compatibilityReference: "compatibility_reference"
};

const splitFilenames = (value: string) => value.split(/[;,|\n]/).map((item) => item.trim()).filter(Boolean);
const clean = (value?: string) => (value ?? "").trim();
const baseName = (value: string) => value.replace(/\\/g, "/").split("/").pop() ?? value;
const sameFileName = (a: string, b: string) => baseName(a).toLowerCase() === baseName(b).toLowerCase();
const hash = (value: string) => Math.abs([...value].reduce((acc, char) => ((acc << 5) - acc + char.charCodeAt(0)) | 0, 0)).toString(36);

const columnLetter = (index: number) => {
  let value = index + 1;
  let result = "";
  while (value) {
    value -= 1;
    result = String.fromCharCode(65 + (value % 26)) + result;
    value = Math.floor(value / 26);
  }
  return result;
};

export const sourceCellFor = (file: UploadedCsvFile, rowIndex: number, columnName: string, value: string): InventorySourceCell => {
  const rowNumber = file.parsed.rowMeta?.[rowIndex]?.rowNumber ?? rowIndex + 2;
  const columnIndex = file.parsed.headers.indexOf(columnName);
  const cell = columnIndex >= 0 ? `${columnLetter(columnIndex)}${rowNumber}` : `row ${rowNumber}`;
  return { file: file.fileName, row: rowNumber, column: columnName, cell, value };
};

const sourceFor = (file: UploadedCsvFile, rowIndex: number, columnName: string, value: string, type: EvidenceSource["type"] = "spreadsheet"): EvidenceSource => {
  const cell = sourceCellFor(file, rowIndex, columnName, value);
  return {
    id: `${file.id}:r${rowIndex + 1}:${columnName}`,
    type,
    label: type === "donor_note" ? "Dismantling note" : "Inventory CSV",
    confidence: 0,
    snippet: value,
    value,
    fileName: file.fileName,
    rowNumber: cell.row,
    columnName,
    cell: cell.cell,
    location: `${file.fileName} · row ${cell.row} · ${columnName} (${cell.cell})`
  };
};

const buildField = (key: ProductFieldKey, row: Record<string, string>, file: UploadedCsvFile, rowIndex: number): EvidenceField => {
  const field = createEmptyField(key);
  const column = fieldColumns[key];
  const value = clean(row[column]);
  const sources: EvidenceSource[] = [];

  if (value || INVENTORY_COLUMNS.includes(column as typeof INVENTORY_COLUMNS[number])) {
    sources.push(sourceFor(file, rowIndex, column, value, key === "donorYearFromNotes" ? "donor_note" : "spreadsheet"));
  }

  if (key === "donorYear") {
    const noteYear = clean(row.donor_year_from_notes);
    if (noteYear) sources.push(sourceFor(file, rowIndex, "donor_year_from_notes", noteYear, "donor_note"));
    const notes = clean(row.notes);
    if (notes) sources.push(sourceFor(file, rowIndex, "notes", notes, "donor_note"));
  }

  return { ...field, value, sources, history: sources };
};

const displayNameFor = (fields: Record<ProductFieldKey, EvidenceField>, fallback: string) => {
  const partType = clean(fields.partType.value);
  const manufacturer = clean(fields.manufacturer.value);
  const vehicle = clean(fields.donorVehicle.value);
  return [fallback, manufacturer, partType || "used part", vehicle && `for ${vehicle}`].filter(Boolean).join(" · ");
};

const imageIdMatches = (filenames: string[], images: UploadedImage[]) =>
  images.filter((image) => filenames.some((name) => sameFileName(name, image.name))).map((image) => image.id);

const emptyFields = () => Object.keys(fieldLabels).reduce<Record<ProductFieldKey, EvidenceField>>((acc, key) => {
  acc[key as ProductFieldKey] = createEmptyField(key as ProductFieldKey);
  return acc;
}, {} as Record<ProductFieldKey, EvidenceField>);

export const buildProductsFromUploads = (csvFiles: UploadedCsvFile[], images: UploadedImage[]): ProductWorkspaceRecord[] => {
  const products = new Map<string, ProductWorkspaceRecord>();

  csvFiles.forEach((file) => {
    file.parsed.rows.forEach((row, rowIndex) => {
      const id = clean(row.product_id);
      if (!id || products.has(id)) return;
      const referencedFilenames = splitFilenames(row.image_filename ?? "");
      const manualImageIds = images.filter((image) => image.productId === id).map((image) => image.id);
      const matchedImageIds = imageIdMatches(referencedFilenames, images);
      const imageIds = Array.from(new Set([...matchedImageIds, ...manualImageIds]));
      const unmatchedFilenames = referencedFilenames.filter((name) => !images.some((image) => sameFileName(name, image.name)));
      const fields = emptyFields();

      Object.keys(fieldLabels).forEach((key) => {
        fields[key as ProductFieldKey] = buildField(key as ProductFieldKey, row, file, rowIndex);
      });

      const product: ProductWorkspaceRecord = {
        id,
        displayName: displayNameFor(fields, id),
        family: fields.partType.value || "Used automotive part",
        rowOrder: rowIndex,
        csvRowId: `${file.id}:${rowIndex}`,
        csvFileName: file.fileName,
        imageIds,
        associatedFilenames: referencedFilenames.filter((name) => images.some((image) => sameFileName(name, image.name))),
        unmatchedFilenames,
        matchIssue: unmatchedFilenames.length ? "CSV image filename has not been uploaded yet." : imageIds.length ? undefined : "No matching image is associated yet.",
        validationColor: "red",
        checksPassedPercent: 0,
        confidencePercent: null,
        imageAnalysisPerformed: false,
        fields,
        analysisState: "not_analyzed",
        readinessStatus: "information_missing",
        readinessScore: 0,
        approvalStatus: "not_reviewed"
      };
      const analyzed = analyzeProduct(product, images);
      products.set(id, { ...analyzed, analysisState: "not_analyzed", draft: undefined });
    });
  });

  if (!products.size && images.length) {
    const fields = emptyFields();
    const product: ProductWorkspaceRecord = {
      id: `image-set-${hash(images.map((image) => image.name).join("|"))}`,
      displayName: "Uploaded images awaiting CSV details",
      family: "Used automotive part",
      rowOrder: 0,
      imageIds: images.map((image) => image.id),
      associatedFilenames: images.map((image) => image.name),
      unmatchedFilenames: [],
      matchIssue: "Image content is attached only; CSV inventory is needed for product details.",
      validationColor: "red",
      checksPassedPercent: 0,
      confidencePercent: null,
      imageAnalysisPerformed: false,
      fields,
      analysisState: "not_analyzed",
      readinessStatus: "information_missing",
      readinessScore: 0,
      approvalStatus: "not_reviewed"
    };
    products.set(product.id, { ...analyzeProduct(product, images), analysisState: "not_analyzed", draft: undefined });
  }

  return Array.from(products.values()).sort((a, b) => a.rowOrder - b.rowOrder || a.id.localeCompare(b.id));
};

export const applyManualAssociation = (images: UploadedImage[], imageId: string, productId: string) =>
  images.map((image) => image.id === imageId ? { ...image, productId, matchStatus: "manual" as const } : image);
