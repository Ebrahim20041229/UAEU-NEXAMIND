import type { EvidenceField, ProductFieldKey, ProductWorkspaceRecord } from "../types/salvage";

const STORAGE_KEY = "salvagetrust.workspace.v3";

interface StoredFieldPatch {
  reviewDecision?: EvidenceField["reviewDecision"];
  reviewedValue?: string;
  reviewContext?: string;
  value?: string;
  status?: EvidenceField["status"];
  history: EvidenceField["history"];
  sources?: EvidenceField["sources"];
}

interface StoredProductPatch {
  fingerprint: string;
  fields: Partial<Record<ProductFieldKey, StoredFieldPatch>>;
  approvalStatus?: ProductWorkspaceRecord["approvalStatus"];
  draft?: ProductWorkspaceRecord["draft"];
}

export const workspaceFingerprint = (product: ProductWorkspaceRecord) => JSON.stringify([product.csvFileName, Object.values(product.fields).map(field => field.history.filter(source => source.type !== "seller_confirmation").map(source => [source.columnName,source.cell,source.value]))]);

type StoredWorkspace = Record<string, StoredProductPatch>;

// Inventory and evidence stay in this page's memory, never persistent browser storage.
let sessionPatches: StoredWorkspace = {};
export const clearWorkspaceData = () => {
  sessionPatches = {};
  for (const key of ["salvagetrust.workspace.v2", "salvagetrust.workspace.v3"]) {
    try { window.localStorage.removeItem(key); } catch { /* Storage may be unavailable. */ }
  }
};
export const loadWorkspacePatches = (): StoredWorkspace => sessionPatches;

export const saveWorkspaceProducts = (products: ProductWorkspaceRecord[]) => {
  const patches = products.reduce<StoredWorkspace>((acc, product) => {
    acc[product.id] = {
      fingerprint: workspaceFingerprint(product),
      approvalStatus: product.approvalStatus,
      draft: product.draft,
      fields: Object.entries(product.fields).reduce<StoredProductPatch["fields"]>((fieldAcc, [key, field]) => {
        const sellerHistory = field.history.filter((source) => source.type === "seller_confirmation");
        if (sellerHistory.length || field.status === "seller_confirmed" || field.status === "rejected") {
          fieldAcc[key as ProductFieldKey] = {
            reviewDecision: field.reviewDecision, reviewedValue: field.reviewedValue, reviewContext: field.reviewContext,
            value: field.value,
            status: field.status,
            history: sellerHistory,
            sources: field.sources.filter((source) => source.type === "seller_confirmation")
          };
        }
        return fieldAcc;
      }, {})
    };
    return acc;
  }, {});
  sessionPatches = patches;
};

export const applyWorkspacePatches = (products: ProductWorkspaceRecord[], patches: StoredWorkspace) =>
  products.map((product) => {
    const patch = patches[product.id];
    if (!patch || patch.fingerprint !== workspaceFingerprint(product)) return product;
    const fields = { ...product.fields };
    Object.entries(patch.fields).forEach(([key, fieldPatch]) => {
      const fieldKey = key as ProductFieldKey;
      const existing = fields[fieldKey];
      if (!existing || !fieldPatch) return;
      fields[fieldKey] = {
        ...existing,
        reviewDecision: fieldPatch.reviewDecision, reviewedValue: fieldPatch.reviewedValue, reviewContext: fieldPatch.reviewContext,
        value: fieldPatch.value ?? existing.value,
        status: fieldPatch.status ?? existing.status,
        history: [...existing.history, ...fieldPatch.history],
        sources: fieldPatch.sources?.length ? fieldPatch.sources : existing.sources
      };
    });
    return { ...product, fields, approvalStatus: patch.approvalStatus ?? product.approvalStatus, draft: patch.draft ?? product.draft };
  });
