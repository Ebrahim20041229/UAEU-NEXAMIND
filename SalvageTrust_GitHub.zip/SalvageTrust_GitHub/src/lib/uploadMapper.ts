import type { EvidenceFormState, EvidenceSource, EvidenceStatus, PartAttribute, PartRecord, UploadedImage } from "../types/salvage";
import { findCsvValue } from "./csvParser";
import { calculateTrustScore } from "./trustEngine";

export const emptyEvidenceForm: EvidenceFormState = {
  partType: "Side-view mirror",
  manufacturer: "",
  partNumber: "",
  donorVehicle: "",
  donorYear: "",
  position: "",
  condition: "",
  testingStatus: "",
  weight: "",
  dimensions: "",
  price: "",
  location: ""
};

export const formFromCsvRow = (row?: Record<string, string>): EvidenceFormState => ({
  partType: findCsvValue(row, ["part_type", "part type", "type"]) || "Side-view mirror",
  manufacturer: findCsvValue(row, ["manufacturer", "make", "brand"]),
  partNumber: findCsvValue(row, ["part_number", "part number", "oem", "oem_number"]),
  donorVehicle: findCsvValue(row, ["donor_vehicle", "donor vehicle", "vehicle", "model"]),
  donorYear: findCsvValue(row, ["donor_year", "donor year", "year"]),
  position: findCsvValue(row, ["position", "side", "left_right"]),
  condition: findCsvValue(row, ["condition", "condition_notes", "notes"]),
  testingStatus: findCsvValue(row, ["testing_status", "testing", "tested"]),
  weight: findCsvValue(row, ["weight", "weight_kg"]),
  dimensions: findCsvValue(row, ["dimensions", "size", "package_dimensions"]),
  price: findCsvValue(row, ["price", "asking_price"]),
  location: findCsvValue(row, ["location", "storage_location", "rack"])
});

const evidence = (id: string, label: string, snippet: string, type: EvidenceSource["type"] = "seller_confirmation", confidence = 0.92): EvidenceSource => ({
  id,
  type,
  label,
  confidence,
  snippet
});

const statusFor = (field: keyof EvidenceFormState, value: string, imageCount: number): EvidenceStatus => {
  if (!value.trim()) return "missing";
  const lower = value.toLowerCase();
  if (field === "partNumber" && (value.includes("?") || value.length < 5)) return "needs_confirmation";
  if (field === "testingStatus" && (lower.includes("untested") || lower.includes("not recorded") || lower.includes("unknown"))) return "needs_confirmation";
  if (field === "condition" && imageCount === 0) return "needs_confirmation";
  return "supported";
};

const attr = (field: keyof EvidenceFormState, label: string, value: string, images: UploadedImage[], csvLoaded: boolean): PartAttribute => {
  const sourceType = csvLoaded ? "spreadsheet" : "seller_confirmation";
  const sources: EvidenceSource[] = value.trim()
    ? [evidence(`${field}-source`, csvLoaded ? "Uploaded CSV" : "Seller evidence form", value, sourceType)]
    : [];

  if (field === "condition" && images.length > 0 && value.trim()) {
    sources.push(evidence("photo-attachments", "Uploaded images", `${images.length} image file(s) attached for seller review`, "photo", 0.8));
  }

  return {
    field: fieldMap[field],
    label,
    value: value.trim() || undefined,
    status: statusFor(field, value, images.length),
    sources
  };
};

const fieldMap: Record<keyof EvidenceFormState, string> = {
  partType: "part_type",
  manufacturer: "manufacturer",
  partNumber: "part_number",
  donorVehicle: "donor_vehicle",
  donorYear: "donor_year",
  position: "position",
  condition: "condition",
  testingStatus: "testing_status",
  weight: "weight",
  dimensions: "dimensions",
  price: "price",
  location: "storage_location"
};

export const buildPartRecordFromUpload = (form: EvidenceFormState, images: UploadedImage[], csvLoaded: boolean): PartRecord => {
  const attributes = [
    attr("partType", "Part type", form.partType, images, csvLoaded),
    attr("manufacturer", "Manufacturer", form.manufacturer, images, csvLoaded),
    attr("partNumber", "Part number", form.partNumber, images, csvLoaded),
    attr("donorVehicle", "Donor vehicle", form.donorVehicle, images, csvLoaded),
    attr("donorYear", "Donor year", form.donorYear, images, csvLoaded),
    attr("position", "Position", form.position, images, csvLoaded),
    attr("condition", "Condition", form.condition, images, csvLoaded),
    attr("testingStatus", "Testing status", form.testingStatus, images, csvLoaded),
    attr("weight", "Weight", form.weight, images, csvLoaded),
    attr("dimensions", "Dimensions", form.dimensions, images, csvLoaded)
  ];

  const record: PartRecord = {
    id: "UPLOADED-001",
    title: `${form.manufacturer || "Unbranded"} ${form.position || ""} ${form.partType || "Auto part"} for ${form.donorVehicle || "unconfirmed donor vehicle"}`.trim(),
    family: form.partType || "Uploaded part",
    image: images[0]?.previewUrl ?? "",
    price: form.price || "Requires price",
    location: form.location || "Requires storage location",
    confidenceScore: 0,
    attributes,
    attemptedUnsafeClaim: `Fits multiple ${form.donorVehicle || "vehicle"} model years without reference evidence.`
  };

  return { ...record, confidenceScore: calculateTrustScore(record) };
};
