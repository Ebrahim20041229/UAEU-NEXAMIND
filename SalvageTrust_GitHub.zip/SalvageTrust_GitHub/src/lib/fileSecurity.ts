export const MAX_CSV_BYTES = 2 * 1024 * 1024;
export const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
export const MAX_IMAGES = 50;
export const MAX_TOTAL_IMAGE_BYTES = 100 * 1024 * 1024;
export async function validateImageFile(file: File): Promise<boolean> {
  if (!/\.(jpe?g|png|webp)$/i.test(file.name) || file.size <= 0 || file.size > MAX_IMAGE_BYTES) return false;
  const b = new Uint8Array(await file.slice(0, 16).arrayBuffer());
  const jpg = b[0] === 255 && b[1] === 216 && b[2] === 255;
  const png = [137,80,78,71,13,10,26,10].every((v,i) => b[i] === v);
  const webp = String.fromCharCode(...b.slice(0,4)) === "RIFF" && String.fromCharCode(...b.slice(8,12)) === "WEBP";
  return /\.jpe?g$/i.test(file.name) ? jpg : /\.png$/i.test(file.name) ? png : webp;
}
