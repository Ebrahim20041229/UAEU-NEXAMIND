import type { PartRecord, ReadinessResult } from "../types/salvage";
import { requiredListingFields, requiredShippingFields } from "../data/checklistRules";
import { detectConflicts } from "./conflictDetector";
import { getAttribute, summarizeTrust } from "./trustEngine";

export const classifyReadiness = (part: PartRecord): ReadinessResult => {
  const conflicts = detectConflicts(part);
  const missingListing = requiredListingFields.filter((field) => !getAttribute(part, field)?.value);
  const invalidListing = requiredListingFields.filter((field) => ["invalid", "rejected"].includes(getAttribute(part, field)?.status ?? ""));
  const missingShipping = requiredShippingFields.filter((field) => !getAttribute(part, field)?.value);
  const needsConfirmation = part.attributes.filter((attribute) => attribute.status === "needs_confirmation" || attribute.status === "unverified");
  const trust = summarizeTrust(part);

  const blockers = [
    ...conflicts.map((conflict) => `Resolve conflict: ${conflict.label}`),
    ...missingListing.map((field) => `Add required listing field: ${field.split("_").join(" ")}`),
    ...invalidListing.map((field) => `Fix invalid field: ${field.split("_").join(" ")}`)
  ];

  const actions = [
    ...blockers,
    ...needsConfirmation.map((attribute) => `Confirm ${attribute.label.toLowerCase()}: ${attribute.value}`),
    ...missingShipping.map((field) => `Add shipping ${field}`),
    "Seller must approve final draft before listing export"
  ];

  if (conflicts.length || missingListing.length || invalidListing.length) {
    return { status: "information_missing", score: trust.score, blockers, actions };
  }

  if (needsConfirmation.length > 0 || missingShipping.length > 0) {
    return { status: "specialist_review_required", score: trust.score, blockers, actions };
  }

  return {
    status: "ready_for_review",
    score: trust.score,
    blockers: [],
    actions: ["Review FitGuard notes", "Confirm seller approval", "Export draft to eBay listing format"]
  };
};
