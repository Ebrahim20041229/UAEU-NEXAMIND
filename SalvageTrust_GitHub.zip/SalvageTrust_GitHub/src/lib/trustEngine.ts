import type { EvidenceStatus, PartAttribute, PartRecord } from "../types/salvage";
import { detectConflicts } from "./conflictDetector";

export const statusWeight: Record<EvidenceStatus, number> = {
  supported: 92,
  seller_confirmed: 85,
  needs_confirmation: 55,
  missing: 0,
  invalid: 20,
  conflict: 15,
  unverified: 35,
  rejected: 0
};

export const getAttribute = (part: PartRecord, field: string) =>
  part.attributes.find((attribute) => attribute.field === field);

export const calculateTrustScore = (part: PartRecord) => {
  if (!part.attributes.length) return 0;
  const total = part.attributes.reduce((sum, attribute) => sum + statusWeight[attribute.status], 0);
  return Math.round(total / part.attributes.length);
};

export const summarizeTrust = (part: PartRecord) => {
  const conflicts = detectConflicts(part);
  const missing = part.attributes.filter((attribute) => attribute.status === "missing" || attribute.status === "invalid");
  const needsConfirmation = part.attributes.filter((attribute) => attribute.status === "needs_confirmation" || attribute.status === "unverified");
  const supported = part.attributes.filter((attribute) => attribute.status === "supported" || attribute.status === "seller_confirmed");

  return {
    score: calculateTrustScore(part),
    conflicts,
    missing,
    needsConfirmation,
    supported,
    issueCount: conflicts.length + missing.length + needsConfirmation.length
  };
};

export const sourceLine = (attribute: PartAttribute) => {
  if (!attribute.sources.length) return "No evidence source yet";
  const bestSource = [...attribute.sources].sort((a, b) => b.confidence - a.confidence)[0];
  return `${bestSource.label} · ${Math.round(bestSource.confidence * 100)}% evidence confidence`;
};
