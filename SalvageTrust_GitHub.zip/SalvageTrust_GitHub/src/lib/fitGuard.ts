import type { CompatibilityRecord, ListingClaim, PartRecord } from "../types/salvage";
import { getAttribute } from "./trustEngine";

export const reviewClaims = (part: PartRecord, reference: CompatibilityRecord[], generatedClaims: ListingClaim[]) => {
  const partNumber = getAttribute(part, "part_number")?.value?.split("?").join("");
  const exactReference = reference.find((record) => record.partNumber === partNumber);

  return generatedClaims.map((claim) => {
    if (claim.claimType === "compatibility" && !exactReference) {
      return {
        ...claim,
        status: "removed" as const,
        reason: "No exact part-number match in the approved compatibility reference dataset.",
        sourceIds: []
      };
    }

    if (claim.claimType === "functionality" && !["supported", "seller_confirmed"].includes(getAttribute(part, "testing_status")?.status ?? "")) {
      return {
        ...claim,
        status: "requires_confirmation" as const,
        reason: "Functionality cannot be claimed until electrical testing is recorded or seller-confirmed.",
        sourceIds: []
      };
    }

    return claim;
  });
};

export const getSupportedCompatibility = (part: PartRecord, reference: CompatibilityRecord[]) => {
  const partNumber = getAttribute(part, "part_number")?.value;
  const record = reference.find((item) => item.partNumber === partNumber);
  return record?.supportedVehicles ?? [];
};
