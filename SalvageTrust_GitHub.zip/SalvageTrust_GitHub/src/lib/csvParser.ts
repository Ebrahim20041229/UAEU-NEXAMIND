import type { ParsedCsv } from "../types/salvage";

export const INVENTORY_COLUMNS = [
  "product_id",
  "image_filename",
  "part_type",
  "manufacturer",
  "part_number",
  "donor_vehicle",
  "donor_year",
  "position",
  "condition",
  "defects",
  "testing_status",
  "included_components",
  "weight_kg",
  "dimensions_cm",
  "asking_price",
  "currency",
  "storage_location",
  "notes",
  "donor_year_from_notes",
  "part_number_legibility",
  "compatibility_reference"
] as const;

export const normalizeCsvKey = (key: string) => key.toLowerCase().replace(/[^a-z0-9]/g, "");

const blank = (value: unknown) => value === null || value === undefined || String(value).trim() === "";

const parseCsvMatrix = (input: string) => {
  const text = String(input).replace(/^\uFEFF/, "");
  const matrix: string[][] = [];
  let record: string[] = [];
  let cell = "";
  let quoted = false;
  let closedQuote = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];

    if (char === '"') {
      if (quoted && next === '"') {
        cell += '"';
        index += 1;
      } else if (quoted) {
        quoted = false; closedQuote = true;
      } else if (cell === "" && !closedQuote) {
        quoted = true;
      } else {
        throw new Error("Invalid quote in CSV. Use standard quoted cells for commas or quotes.");
      }
    } else if (!quoted && char === ",") {
      record.push(cell);
      cell = ""; closedQuote = false;
    } else if (!quoted && (char === "\n" || char === "\r")) {
      if (char === "\r" && next === "\n") index += 1;
      record.push(cell);
      matrix.push(record);
      record = [];
      cell = ""; closedQuote = false;
    } else {
      if (closedQuote) throw new Error("Invalid quote in CSV. Use standard quoted cells for commas or quotes.");
      cell += char;
    }
  }

  if (quoted) throw new Error("Unclosed CSV quote.");
  if (cell !== "" || record.length) {
    record.push(cell);
    matrix.push(record);
  }

  while (matrix.length && matrix[matrix.length - 1].every(blank)) matrix.pop();
  return matrix;
};

export const parseCsv = (fileName: string, text: string): ParsedCsv => {
  if (new TextEncoder().encode(text).length > 2 * 1024 * 1024) throw new Error("Use a CSV file up to 2 MB.");
  const rawMatrix = parseCsvMatrix(text);
  if (rawMatrix.length > 1001 || rawMatrix.some(row => row.length > 64 || row.some(cell => cell.length > 10000))) throw new Error("CSV limit: 1000 products, 64 columns and 10000 characters per cell.");
  const rowNumbers = rawMatrix.map((_,index) => index+1).filter((_,index) => !rawMatrix[index].every(blank));
  const matrix = rawMatrix.filter((row) => !row.every(blank));
  if (!matrix.length) throw new Error("CSV file is empty.");

  const headers = matrix[0].map((header) => header.trim());
  if (new Set(headers).size !== headers.length) throw new Error("Duplicate CSV column names are not allowed.");

  const missing = INVENTORY_COLUMNS.filter((column) => !headers.includes(column));
  if (missing.length) throw new Error(`Missing CSV columns: ${missing.join(", ")}.`);

  const rows: Record<string, string>[] = [];
  const rowMeta: ParsedCsv["rowMeta"] = [];
  const seenProductIds = new Set<string>();

  matrix.slice(1).forEach((values, index) => {
    const rowNumber = rowNumbers[index+1];
    if (values.length !== headers.length) {
      throw new Error(`Incorrect cell count in CSV row ${rowNumber}: found ${values.length}, expected ${headers.length}.`);
    }

    const row = headers.reduce<Record<string, string>>((acc, header, valueIndex) => {
      acc[header] = values[valueIndex] ?? "";
      return acc;
    }, Object.create(null));

    const productId = row.product_id?.trim();
    if (productId && (!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$/.test(productId) || ["__proto__","prototype","constructor"].includes(productId))) throw new Error("Product IDs must use safe letters, digits, dots, underscores or hyphens.");
    if (!productId) throw new Error(`Missing product_id in CSV row ${rowNumber}.`);
    if (seenProductIds.has(productId)) throw new Error(`Duplicate product_id: ${productId}.`);
    seenProductIds.add(productId);

    rows.push(row);
    rowMeta?.push({ rowNumber, widthMismatch: false, extraValues: [] });
  });

  return { fileName, headers, rows, rowMeta, warnings: [] };
};

export const findCsvValue = (row: Record<string, string> | undefined, aliases: string[]) => {
  if (!row) return "";
  const normalized = Object.entries(row).reduce<Record<string, string>>((acc, [key, value]) => {
    acc[normalizeCsvKey(key)] = String(value ?? "");
    return acc;
  }, {});

  for (const alias of aliases) {
    const value = normalized[normalizeCsvKey(alias)];
    if (value) return value;
  }

  return "";
};

export const findCsvColumn = (row: Record<string, string> | undefined, aliases: string[]) => {
  if (!row) return undefined;
  return Object.keys(row).find((key) => aliases.some((alias) => normalizeCsvKey(alias) === normalizeCsvKey(key)));
};
