import type { EvidenceField, EvidenceSource, EvidenceStatus, ProductFieldKey, ProductWorkspaceRecord, ReadinessStatus, UploadedImage, WorkspaceSummary } from "../types/salvage";

export const primaryFieldKeys: ProductFieldKey[] = [
  "partType",
  "manufacturer",
  "partNumber",
  "donorVehicle",
  "donorYear",
  "position",
  "condition",
  "testingStatus"
];

export const secondaryFieldKeys: ProductFieldKey[] = [
  "defects",
  "includedComponents",
  "weightKg",
  "dimensionsCm",
  "askingPrice",
  "currency",
  "storageLocation",
  "notes",
  "donorYearFromNotes",
  "partNumberLegibility",
  "compatibilityReference",
  "imageFilename",
  "productId"
];

export const fieldLabels: Record<ProductFieldKey, string> = {
  productId: "Product ID",
  imageFilename: "Image filename",
  partType: "Part type",
  manufacturer: "Manufacturer",
  partNumber: "Part number",
  donorVehicle: "Donor vehicle",
  donorYear: "Donor year",
  position: "Position",
  condition: "Condition",
  defects: "Known defects",
  testingStatus: "Testing status",
  includedComponents: "Included components",
  weightKg: "Net weight (kg)",
  dimensionsCm: "Item/lot dimensions (cm)",
  askingPrice: "Asking price",
  currency: "Currency",
  storageLocation: "Storage location",
  notes: "Inventory notes",
  donorYearFromNotes: "Donor year from notes",
  partNumberLegibility: "Part-number legibility",
  compatibilityReference: "Compatibility reference"
};

const requiredFields = new Set<ProductFieldKey>([
  "productId",
  "imageFilename",
  "partType",
  "manufacturer",
  "partNumber",
  "donorVehicle",
  "donorYear",
  "position",
  "condition",
  "defects",
  "testingStatus",
  "includedComponents",
  "weightKg",
  "dimensionsCm"
]);

const blockingKeys = new Set<ProductFieldKey>([...requiredFields, "partNumberLegibility"]);
const normalize = (value?: string) => (value ?? "").trim();
const lower = (value?: string) => normalize(value).toLowerCase();
const blank = (value?: string) => normalize(value) === "";
const numeric = (value?: string) => blank(value) ? null : Number(value);
const currentYear = () => new Date().getUTCFullYear();
const validYear = (value: number | null) => value !== null && Number.isInteger(value) && value >= 1900 && value <= currentYear() + 1;
const statusRank: Record<EvidenceStatus, number> = { supported: 0, seller_confirmed: 0, unverified: 1, needs_confirmation: 2, missing: 3, invalid: 3, conflict: 3, rejected: 3 };

export const createEmptyField = (key: ProductFieldKey): EvidenceField => ({
  key,
  label: fieldLabels[key],
  status: "missing",
  blocking: requiredFields.has(key),
  confidenceExplanation: "Not available. This CSV rules prototype does not compute calibrated AI confidence.",
  sources: [],
  history: []
});

const sourceValue = (field: EvidenceField) => normalize(field.value);
const markField = (field: EvidenceField, status: EvidenceStatus, code: string, issue: string, blocking = true, relatedSources: EvidenceSource[] = []): EvidenceField => ({
  ...field,
  status,
  code,
  issue,
  blocking,
  relatedSources,
  confidence: undefined,
  confidenceExplanation: "Not available. Status is rule-based from CSV values, source agreement and seller overrides; it is not calibrated AI confidence."
});

const passField = (field: EvidenceField): EvidenceField => {
  const status: EvidenceStatus = "supported";
  return {
    ...field,
    status,
    code: "recorded_in_csv",
    issue: undefined,
    blocking: false,
    relatedSources: undefined,
    confidence: undefined,
    confidenceExplanation: "Not available. This prototype reports deterministic rule status instead of AI confidence."
  };
};

const withWorseStatus = (field: EvidenceField, next: EvidenceField) => statusRank[next.status] >= statusRank[field.status] ? next : field;

/** Bind confirmations to the facts that made them reviewable. No source data is overwritten. */
export const reviewContextFor = (fields: ProductWorkspaceRecord["fields"], key: ProductFieldKey): string => {
  const dependencies: Partial<Record<ProductFieldKey, ProductFieldKey[]>> = {
    partNumber: ["partNumberLegibility", "manufacturer"],
    donorYear: ["donorYearFromNotes", "donorVehicle"],
    condition: ["testingStatus", "defects"],
    testingStatus: ["condition"],
    position: ["partType", "donorVehicle"]
  };
  return JSON.stringify((dependencies[key] ?? []).map(dependency => [dependency, fields[dependency].value ?? ""]));
};

export const analyzeProduct = (product: ProductWorkspaceRecord, images: UploadedImage[] = []): ProductWorkspaceRecord => {
  const fields = Object.entries(product.fields).reduce<Record<ProductFieldKey, EvidenceField>>((acc, [key, field]) => {
    acc[key as ProductFieldKey] = sourceValue(field) ? passField(field) : { ...field, status: "missing", blocking: requiredFields.has(key as ProductFieldKey) };
    return acc;
  }, {} as Record<ProductFieldKey, EvidenceField>);

  requiredFields.forEach((key) => {
    if (blank(fields[key].value)) {
      fields[key] = markField(fields[key], "missing", "missing_value", "Required inventory information is missing.");
    }
  });

  const imageNames = new Set(images.map((image) => image.name.toLowerCase()));
  const manuallyMatched = images.some(image => image.productId === product.id);
  const expectedImages = normalize(fields.imageFilename.value).split(/[;,|\n]/).map((name) => name.trim()).filter(Boolean);
  if (!manuallyMatched && expectedImages.length && expectedImages.some((name) => !imageNames.has(name.toLowerCase()))) {
    fields.imageFilename = markField(fields.imageFilename, "missing", "image_not_uploaded", "The CSV image filename has not been uploaded or matched yet.");
  }

  const donorYear = numeric(fields.donorYear.value);
  const noteYear = numeric(fields.donorYearFromNotes.value);
  if (!blank(fields.donorYear.value) && !validYear(donorYear)) {
    fields.donorYear = markField(fields.donorYear, "invalid", "invalid_year", "Donor year is outside a plausible vehicle year range.");
  }
  if (!blank(fields.donorYearFromNotes.value) && !validYear(noteYear)) {
    fields.donorYearFromNotes = markField(fields.donorYearFromNotes, "invalid", "invalid_year", "The donor year recorded in notes is implausible.");
  }
  if (validYear(donorYear) && validYear(noteYear) && donorYear !== noteYear) {
    fields.donorYear = markField(
      fields.donorYear,
      "conflict",
      "year_conflict",
      `CSV donor year ${fields.donorYear.value} conflicts with note year ${fields.donorYearFromNotes.value}.`,
      true,
      [...fields.donorYearFromNotes.sources, ...fields.notes.sources]
    );
  }

  const legibility = lower(fields.partNumberLegibility.value);
  if (!blank(fields.partNumber.value) && (legibility === "unclear" || legibility === "missing")) {
    fields.partNumber = markField(fields.partNumber, "needs_confirmation", "identifier_needs_confirmation", "Part-number reading needs seller confirmation.", true, [...fields.partNumberLegibility.sources, ...fields.notes.sources]);
  } else if (!blank(fields.partNumber.value) && legibility && legibility !== "clear") {
    fields.partNumberLegibility = markField(fields.partNumberLegibility, "needs_confirmation", "legibility_not_recorded", "Part-number legibility is not recorded clearly.");
  }

  const positions = new Set(["left", "right", "center", "rear", "left_right", "set"]);
  const position = lower(fields.position.value);
  if (position === "unconfirmed") {
    fields.position = markField(fields.position, "needs_confirmation", "position_needs_confirmation", "Installation position needs seller confirmation.", true, fields.notes.sources);
  } else if (!blank(fields.position.value) && !positions.has(position)) {
    fields.position = markField(fields.position, "invalid", "invalid_position", "Position must be left, right, center, rear, left_right or set.");
  }

  const condition = lower(fields.condition.value);
  if (condition === "for_parts") {
    fields.condition = markField(fields.condition, "invalid", "specialist_review_required", "For-parts condition requires specialist review under the demo policy.", true, [...fields.defects.sources, ...fields.notes.sources]);
  } else if (!blank(fields.condition.value) && condition !== "used") {
    fields.condition = markField(fields.condition, "invalid", "invalid_condition", "Condition must be used or for_parts for this demo.");
  }

  const testing = lower(fields.testingStatus.value);
  if (testing === "not_recorded") {
    fields.testingStatus = markField(fields.testingStatus, "needs_confirmation", "testing_not_recorded", "Testing status has not been recorded; do not claim functionality.", true, fields.notes.sources);
  } else if (testing === "faulty") {
    fields.testingStatus = markField(fields.testingStatus, "needs_confirmation", "faulty_disclosure_required", "Faulty operation must remain disclosed.");
    if (condition !== "for_parts") fields.condition = markField(fields.condition, "invalid", "condition_test_conflict", "Faulty testing conflicts with a normal used condition.", true, fields.testingStatus.sources);
  } else if (!blank(fields.testingStatus.value) && !["tested_working", "untested"].includes(testing)) {
    fields.testingStatus = markField(fields.testingStatus, "invalid", "invalid_testing_status", "Testing status must be tested_working, untested or not_recorded.");
  }

  const weight = numeric(fields.weightKg.value);
  if (weight !== null && (!Number.isFinite(weight) || weight <= 0)) fields.weightKg = markField(fields.weightKg, "invalid", "invalid_net_weight", "Net item/lot weight must be greater than zero.");

  if (!blank(fields.dimensionsCm.value)) {
    const dimensions = normalize(fields.dimensionsCm.value).split(/\s*[xX×]\s*/).map(Number);
    if (dimensions.length !== 3 || dimensions.some((item) => !Number.isFinite(item) || item <= 0)) {
      fields.dimensionsCm = markField(fields.dimensionsCm, "invalid", "invalid_dimensions", "Dimensions must include three positive values, for example 16 x 12 x 9.");
    }
  }

  const price = numeric(fields.askingPrice.value);
  if (price === null) fields.askingPrice = markField(fields.askingPrice, "needs_confirmation", "price_not_recorded", "Asking price is not recorded.", false);
  else if (!Number.isFinite(price) || price < 0) fields.askingPrice = markField(fields.askingPrice, "invalid", "invalid_price", "Asking price must be zero or greater.");

  if (!/^[A-Z]{3}$/.test(normalize(fields.currency.value))) {
    fields.currency = markField(fields.currency, "invalid", "invalid_currency", "Currency must be a three-letter code such as AED.");
  }

  fields.compatibilityReference = markField(
    fields.compatibilityReference,
    "unverified",
    blank(fields.compatibilityReference.value) ? "compatibility_unverified" : "reference_not_verified",
    blank(fields.compatibilityReference.value) ? "No independent compatibility reference is supplied." : "A reference string alone does not prove fitment.",
    false
  );

  // Seller decisions survive automatic revalidation, but cannot bypass invalid values.
  for (const key of Object.keys(fields) as ProductFieldKey[]) {
    const field = fields[key];
    const original = product.fields[key];
    if (original.reviewedValue !== field.value) continue;
    if (original.reviewDecision === "confirmed" && original.reviewContext !== reviewContextFor(fields,key)) continue;
    if (original.reviewDecision === "confirmed" && key === "partNumber" && field.code === "identifier_needs_confirmation") {
      fields[key] = {...field, status:"seller_confirmed", code:"seller_entered", issue:undefined, blocking:false};
    } else if (original.reviewDecision === "rejected") {
      fields[key] = markField(field, "rejected", "seller_rejected", "Seller rejected this value.", true);
    } else if (original.reviewDecision === "needs_review" && ["supported","seller_confirmed","unverified"].includes(field.status)) {
      fields[key] = markField(field, "needs_confirmation", "seller_review", "Seller marked this field for review.", key !== "compatibilityReference");
    } else if (original.reviewDecision === "confirmed" && ["supported","seller_confirmed"].includes(field.status)) {
      fields[key] = {...field, status:"seller_confirmed", code:"seller_entered"};
    }
  }
  const fieldList = Object.values(fields);
  const blockingIssues = fieldList.filter((field) => field.blocking && field.status !== "supported" && field.status !== "seller_confirmed");
  const specialist = condition === "for_parts" || fields.condition.code === "condition_test_conflict";
  const validationColor: ProductWorkspaceRecord["validationColor"] = blockingIssues.some((issue) => ["missing", "invalid", "conflict", "rejected"].includes(issue.status)) ? "red" : blockingIssues.length ? "amber" : "green";
  const readinessStatus: ReadinessStatus = specialist ? "specialist_review_required" : blockingIssues.length ? "information_missing" : "ready_for_review";
  const passed = Array.from(requiredFields).filter((key) => fields[key].status === "supported" || fields[key].status === "seller_confirmed").length;

  return {
    ...product,
    fields,
    validationColor,
    readinessStatus,
    readinessScore: Math.round((100 * passed) / requiredFields.size),
    checksPassedPercent: Math.round((100 * passed) / requiredFields.size),
    confidencePercent: null,
    imageAnalysisPerformed: false,
    analysisState: "analyzed",
    error: undefined,
    updatedAt: new Date().toISOString()
  };
};

export const summarizeProduct = (product: ProductWorkspaceRecord) => {
  const fields = Object.values(product.fields);
  const supported = fields.filter((field) => field.status === "supported" || field.status === "seller_confirmed").length;
  const needs = fields.filter((field) => field.status === "needs_confirmation" || field.status === "unverified").length;
  const issues = fields.filter((field) => ["missing", "invalid", "conflict", "rejected"].includes(field.status)).length;
  const topIssue = fields.find((field) => field.blocking && ["conflict", "invalid", "missing", "needs_confirmation"].includes(field.status));
  return { supported, needs, issues, nextAction: topIssue ? `${topIssue.label}: ${topIssue.issue ?? "Review evidence."}` : "Review the draft and seller approval." };
};

export const summarizeWorkspace = (products: ProductWorkspaceRecord[], {priorityCurrency = "AED"}: {priorityCurrency?: string} = {}): WorkspaceSummary => {
  const summary: WorkspaceSummary = { total: products.length, missing: 0, specialist: 0, ready: 0, green: 0, amber: 0, red: 0, inventoryValueByCurrency: {}, readyValueByCurrency: {}, nextProductId: null };
  const nextCandidates: ProductWorkspaceRecord[] = [];

  products.forEach((product) => {
    summary[product.validationColor] += 1;
    if (product.readinessStatus === "ready_for_review") summary.ready += 1;
    if (product.readinessStatus === "information_missing") {
      summary.missing += 1;
      nextCandidates.push(product);
    }
    if (product.readinessStatus === "specialist_review_required") summary.specialist += 1;

    const price = numeric(product.fields.askingPrice.value);
    const currency = normalize(product.fields.currency.value);
    if (price !== null && Number.isFinite(price) && price >= 0 && /^[A-Z]{3}$/.test(currency)) {
      summary.inventoryValueByCurrency[currency] = (summary.inventoryValueByCurrency[currency] ?? 0) + price;
      if (product.readinessStatus === "ready_for_review") summary.readyValueByCurrency[currency] = (summary.readyValueByCurrency[currency] ?? 0) + price;
    }
  });

  // Compare asking prices only within one currency; no implicit FX conversion.
  const blockingCount = (product: ProductWorkspaceRecord) => Object.values(product.fields).filter(field => field.blocking && !["supported","seller_confirmed"].includes(field.status)).length;
  const prioritized = nextCandidates.filter(product => normalize(product.fields.currency.value) === priorityCurrency);
  summary.nextProductId = prioritized.sort((a,b) => blockingCount(a)-blockingCount(b) || (numeric(b.fields.askingPrice.value) ?? -1) - (numeric(a.fields.askingPrice.value) ?? -1) || a.id.localeCompare(b.id))[0]?.id ?? null;
  // Round currency groups to their own minor units, never mix currencies.
  for (const values of [summary.inventoryValueByCurrency,summary.readyValueByCurrency]) {
    for (const currency of Object.keys(values)) {
      const digits = new Intl.NumberFormat("en",{style:"currency",currency}).resolvedOptions().maximumFractionDigits ?? 2;
      const scale = 10 ** digits;
      values[currency] = Math.round((values[currency]+Number.EPSILON)*scale)/scale;
    }
  }

  return summary;
};
