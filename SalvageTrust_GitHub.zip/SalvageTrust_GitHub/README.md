# SalvageTrust — submission

A browser-based evidence-review prototype for used automotive-part sellers. Upload CSV and images, select a part, review missing/conflicting data, correct it, and generate an editable eBay draft.

## Open immediately
Extract the full ZIP and open **OPEN_SITE.html** in Chrome or Edge. It includes the built app, CSS and scripts and needs no runtime downloads. Upload DEMO_FILES/SalvageTrust_Demo_Inventory.csv and the ten files in DEMO_FILES/images. Their names must remain unchanged. Use synthetic/anonymized data only.

## Source and setup
Source: src/. Requires a supported Node.js installation for development.

```sh
npm ci --legacy-peer-deps
npm run dev:source
```

Open http://127.0.0.1:5173. The development server binds to loopback only. Production build: npm run build. START_SITE.bat provides the same development startup on Windows. OPEN_SITE.html is a separately packaged build of this submitted source; changing source requires rebuilding/repackaging it.

## Reproduce the normal and difficult journeys
1. Upload the supplied CSV and images; select P001; click Analyze product; inspect the draft and sources.
2. Select P009: CSV year 2018 conflicts with note year 2017. Edit year to 2017 and Save changes. The source still retains 2018. Ready parts increase from 4 to 5; ready asking value changes from AED 510 to AED 810.
3. Confirm the unclear P005 part number after reviewing it. It becomes seller-confirmed, not independently authenticated.
4. Toggle Arabic: interface/direction change; imported English notes remain unchanged.
5. Click Clear session data. Uploaded records/images are removed from this page. Reload starts a new empty session.

## Data and trust boundaries
Fictional specifications and seller test statements are demonstration inputs. No AI image recognition, OEM authenticity certification, verified fitment catalog, actual eBay publication, shipping booking or legal/customs clearance is implemented. Status percentages are data-check results, not calibrated AI confidence. Weights are net item/lot weights without packaging.

See SUBMISSION_NOTE.md for evaluation mapping, SECURITY.md for protections/limitations and TEST_RESULTS.md for checks performed. See READ_FIRST_AR.txt for Arabic startup instructions.

## Reproduce the internal checks

Requires Node.js 20 or newer. After npm ci --legacy-peer-deps, run:

```sh
npm test
npm run test:report
npm run build
```

The test report is saved to reports/validation-results.json. Build also recreates OPEN_SITE.html with fresh CSP hashes and reports/source-manifest.json. Tests use synthetic/adversarial fixtures and do not execute the answer key as application logic. A passing test suite is not calibrated AI accuracy or a security certification. Interface-lock tests protect the 26 unrelated interface/style files; the evidence display and Arabic translation updates are explicitly allowed.

## Live demo and GitHub source

Current hosted demo: https://salvagetrust-ebrahim-4c015a.astutezebra16384.chatgpt.site
The hosted demo currently requires the owner's ChatGPT account. This GitHub source export includes the latest compact evidence display. The full source history and deployment configuration are not included.

`OPEN_SITE.html` opens the complete offline prototype after downloading and extracting this repository. GitHub's file viewer displays source; it does not run the app. Upload `DEMO_FILES/SalvageTrust_Demo_Inventory.csv` and the ten original images from `DEMO_FILES/images` to test it.

For local source development, run `npm ci --legacy-peer-deps` then `npm run dev:source`. For a production bundle, run `npm run build`; the build creates `dist/index.html` and refreshes `OPEN_SITE.html`.

Publishing this source repository does not automatically deploy or synchronize edits to the existing hosted demo.
