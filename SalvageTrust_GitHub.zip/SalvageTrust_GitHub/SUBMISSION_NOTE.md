# SalvageTrust — supporting submission note

## Problem and business value
Salvage sellers must reconcile scattered inventory notes/photos before listing used parts. Missing identifiers, conflicting donor years and unsupported fitment claims make listing preparation slow and unreliable. SalvageTrust provides a short review workflow with field-level provenance, editable drafts and a next-action priority.

## Data and approach
Ten synthetic dashboard-air-vent records and ten supplied images. CSV is parsed at runtime; images match by filename. Deterministic checks identify missing/invalid data, unclear identifiers and year conflicts. Seller decisions are tracked separately from automatic checks. No live AI service or image recognition is integrated. Supporting English notes remain original evidence in Arabic mode.

## Demonstrated results
Baseline: 10 records, 4 green / 3 amber / 3 red; 4 ready, 5 missing information and 1 specialist case. Total asking value AED 1660; ready asking value AED 510. Correcting P009 from 2018 to 2017 produces 5 ready and AED 810 ready value, with original source values retained. These are asking-price totals, not realized revenue. Runtime validation and UI interaction tests are documented in TEST_RESULTS.md. Manual-workflow preparation-time improvements and model accuracy were not measured; no fabricated speed or accuracy claim is made.

## Mapping to the supplied eBay judging rubric
| Criterion | Weight | Evidence in this submission |
|---|---:|---|
| Business relevance and value | 30% | Seller evidence consolidation, prioritization and inventory asking-value summaries; pilot measurement still required. |
| AI quality and evidence | 25% | Traceable CSV cells, explicit uncertainty, no invented fitment, retained source conflicts. AI-model quality is not demonstrated by this rules-based prototype. |
| Working prototype | 20% | Reproducible CSV/photo import, normal journey and year-conflict correction, editable draft, source/setup instructions. |
| Seller experience | 15% | Light interface, English/Arabic RTL, selected-product review, explicit Save/Cancel and concise actions. |
| Responsible design and scalability | 10% | Session-only data, explicit deletion, upload limits, local processing, human approval and a documented production roadmap. Privacy/security is part of this criterion, not a separate guaranteed score. |

## Pilot requirements and limitations
Use approved/anonymized inventory; benchmark manual versus assisted preparation time, correction rate, disclosure completeness and missing/conflict detection. A real deployment needs authenticated users, server-side authorization/validation, tenant isolation, encrypted transport/storage with key management, retention controls, trusted fitment sources and operational monitoring. These production controls are not claimed for this offline prototype. No production credentials or identifiable seller/buyer records are included or required.

## Internal reliability revision — interface preserved

The revision adds executable tests and changes backend logic only. Evidence confirmations are bound to their dependent values, so a changed manufacturer/identifier context requires rechecking instead of inheriting an old green decision. Stale asynchronous file reads cannot overwrite newer selections or restore a cleared session. Rejected functionality is excluded from generated working-condition claims; CSV quoting is stricter; prices are prioritized within a chosen currency and totals are rounded to that currency's precision.

Evidence: 33 passing Node tests in reports/validation-results.json, the test sources in tests/, unchanged interface checks in reports/unchanged-interface.json, and reproducible source/build hashes in reports/source-manifest.json. The 28 UI/style/translation files, App JSX and compiled CSS match the prior submission. No new screens, controls, colors or layout changes were introduced in this revision. These improvements support working-prototype, traceability and responsible-design assessment; no score increase is guaranteed.

## Latest seller-UX revision

Evidence now defaults to a short Source / Value summary, with the other value shown for conflicts. Dates, full notes and edit history are available on demand under Source details and history. No source values or validation rules were removed. This is an explicitly requested evidence-panel change; unrelated interface structure is preserved. Verification: 38 passing tests in reports/validation-results.json.
