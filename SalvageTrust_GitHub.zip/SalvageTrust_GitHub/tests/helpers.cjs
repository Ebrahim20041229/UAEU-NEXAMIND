const fs=require('node:fs'),path=require('node:path'),ts=require('typescript');
for(const ext of ['.ts','.tsx'])require.extensions[ext]=(module,file)=>module._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020,esModuleInterop:true,jsx:ts.JsxEmit.ReactJSX}}).outputText,file);
const {parseCsv,INVENTORY_COLUMNS}=require('../src/lib/csvParser.ts');
const {buildProductsFromUploads}=require('../src/lib/productImporter.ts');
const {analyzeProduct,reviewContextFor,summarizeWorkspace}=require('../src/lib/productAnalysis.ts');
const {generateWorkspaceDraft}=require('../src/lib/listingGenerator.ts');
const filename='SalvageTrust_Demo_Inventory.csv';
const text=fs.readFileSync(path.join(__dirname,'../DEMO_FILES',filename),'utf8');
const parsed=parseCsv(filename,text);
const images=parsed.rows.map((row,i)=>({id:'image-'+i,name:row.image_filename,size:100,type:'image/jpeg',previewUrl:'blob:test-'+i}));
const file={id:'test-data',fileName:filename,parsed,uploadedAt:'2026-10-28',size:Buffer.byteLength(text)};
function fresh(){return buildProductsFromUploads([file],images);}
function product(id){return fresh().find(p=>p.id===id);}
function value(p,key,value){const next=structuredClone(p);next.fields[key].value=value;return next;}
function review(p,key,decision='confirmed'){
 const next=structuredClone(p);Object.assign(next.fields[key],{reviewDecision:decision,reviewedValue:next.fields[key].value,reviewContext:reviewContextFor(next.fields,key)});return analyzeProduct(next,images);
}
function serialize(headers,rows){const cell=x=>'"'+String(x??'').replaceAll('"','""')+'"';return [headers,...rows.map(row=>headers.map(h=>row[h]??''))].map(row=>row.map(cell).join(',')).join('\r\n');}
module.exports={fs,path,ts,text,parsed,parseCsv,INVENTORY_COLUMNS,images,file,fresh,product,value,review,serialize,analyzeProduct,reviewContextFor,summarizeWorkspace,generateWorkspaceDraft,buildProductsFromUploads};
