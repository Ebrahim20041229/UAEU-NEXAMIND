const test=require('node:test'),assert=require('node:assert/strict');
const h=require('./helpers.cjs');
const React=require('react'),{renderToStaticMarkup}=require('react-dom/server');
const {buildEvidencePreview,briefEvidenceIssue}=require('../src/lib/evidencePreview.ts');
const {EvidenceDetails}=require('../src/components/EvidenceFieldCard.tsx');
const {LocaleProvider}=require('../src/i18n/locale.tsx');
function editedTesting(){
 const p=h.product('P007'),field=structuredClone(p.fields.testingStatus),original=field.sources[0];
 field.sources=[{id:'seller-test',type:'seller_confirmation',label:'Seller edit',confidence:0,snippet:'not_recorded',value:'not_recorded',createdAt:'2026-10-28T07:22:51.602Z',reason:'Seller correction or confirmation',originalSource:{file:original.fileName,row:original.rowNumber,column:original.columnName,cell:original.cell,value:original.value}}];
 field.history.push(...field.sources);return field;
}
test('default evidence is concise and keeps the actual CSV reference for a seller edit',()=>{
 const field=editedTesting(),before=JSON.stringify(field),preview=buildEvidencePreview(field);
 assert.equal(preview.label,'Seller edit');assert.equal(preview.pointer.row,8);assert.equal(preview.pointer.cell,'K8');
 const html=renderToStaticMarkup(React.createElement(EvidenceDetails,{field}));
 assert.match(html,/K8/);assert.match(html,/Not recorded/);assert.equal(preview.value,"not_recorded");assert.doesNotMatch(html,/Synthetic demo record|2026-10-28T07:22:51|ACTIVE EVIDENCE|RETAINED HISTORY/);
 assert.match(html,/Source details and history/);assert.equal(JSON.stringify(field),before);
});
test('year conflicts expose both short values and their real source cells',()=>{
 const field=h.product('P009').fields.donorYear;
 const preview=buildEvidencePreview(field);assert.equal(preview.value,'2018');assert.equal(preview.pointer.cell,'G10');
 assert.deepEqual(preview.alternatives.map(s=>[s.cell,s.value]),[['S10','2017']]);
 const html=renderToStaticMarkup(React.createElement(EvidenceDetails,{field}));assert.match(html,/2018/);assert.match(html,/2017/);assert.match(html,/S10/);
});
test('Arabic summary localizes enums without changing original evidence text',()=>{
 const field=editedTesting(),html=renderToStaticMarkup(React.createElement(LocaleProvider,{language:'ar'},React.createElement(EvidenceDetails,{field})));
 assert.match(html,/تعديل البائع/);assert.match(html,/لم تُسجّل نتيجة الاختبار/);assert.match(html,/التفاصيل والسجل/);
 const preview=buildEvidencePreview(field);assert.ok(preview.details.some(s=>s.snippet.includes('Synthetic demo record')));assert.equal(field.value,'not_recorded');
});
test('source display does not invent locations when evidence is absent',()=>{
 const field=h.product('P001').fields.weightKg;const missing={...field,value:'',sources:[],history:[],relatedSources:[]};
 const preview=buildEvidencePreview(missing);assert.equal(preview.pointer.cell,undefined);assert.equal(preview.pointer.row,undefined);assert.equal(preview.label,'No supporting evidence.');
});
test('short messages retain the full original check reason in the record',()=>{
 const field=h.product('P007').fields.testingStatus;const original=field.issue;
 assert.equal(briefEvidenceIssue(field),'Confirm the testing status.');assert.equal(field.issue,original);
});
