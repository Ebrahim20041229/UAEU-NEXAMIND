const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.join(__dirname,'..'),assets=path.join(root,'dist/assets');
const files=fs.readdirSync(assets);const js=fs.readFileSync(path.join(assets,files.find(n=>n.endsWith('.js'))),'utf8').replaceAll('</script','<\\/script');const css=fs.readFileSync(path.join(assets,files.find(n=>n.endsWith('.css'))),'utf8');
const hash=s=>crypto.createHash('sha256').update(s).digest('base64');
const policy=`default-src 'none'; script-src 'sha256-${hash(js)}'; style-src 'sha256-${hash(css)}'; img-src blob: data:; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-src 'none'`;
const html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="'+policy+'"><meta name="referrer" content="no-referrer"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SalvageTrust</title><style>'+css+'</style></head><body><div id="root"></div><script>'+js+'</script></body></html>';
fs.writeFileSync(path.join(root,'OPEN_SITE.html'),html);
fs.writeFileSync(path.join(root,'dist/index.html'),html);
const manifest={purpose:'Identify the delivered source/build bytes; not a signature, certification or independent security audit.',files:{}};
function walk(dir){for(const n of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,n.name);if(n.isDirectory())walk(p);else manifest.files[path.relative(root,p).replaceAll(path.sep,'/')]=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');}}
walk(path.join(root,'src'));walk(path.join(root,'dist'));manifest.files['OPEN_SITE.html']=crypto.createHash('sha256').update(html).digest('hex');fs.mkdirSync(path.join(root,'reports'),{recursive:true});fs.writeFileSync(path.join(root,'reports/source-manifest.json'),JSON.stringify(manifest,null,2));
console.log('Standalone page, CSP hashes and source manifest generated.');
